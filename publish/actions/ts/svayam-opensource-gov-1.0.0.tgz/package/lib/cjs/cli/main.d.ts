import { type MenuContext } from "./menu.js";
/**
 * `gov setup` — the interactive workspace BOOTSTRAP (port of setup.sh). Async
 * (readline prompts), so bin.ts routes it here instead of through sync `main`.
 * Runs in cwd (the cloned framework repo), before any resolution.
 */
export declare function runSetupCommand(argv: readonly string[], now?: string): Promise<number>;
/** Read the CLI's own version from its package.json (falls back to "?"). */
export declare function readCliVersion(): string;
/** Gather the best-effort banner context for the interactive menu (all optional). */
export declare function gatherMenuContext(): Promise<MenuContext>;
/** Route any command (setup / enterprise plugin / normal) — used by the menu. */
export declare function runAny(argv: readonly string[]): Promise<number> | number;
/** The command reference shown under the Help menu (grouped) / per-command. */
export declare function helpLines(command?: string): string[];
/** Build + run the interactive main menu (no-args TTY). Async — routed from bin.ts. */
export declare function runMainMenu(): Promise<number>;
/**
 * Enterprise plugin commands (`deploy`/`catalog`/`data`/…) — resolve the gov
 * workspace + config, then delegate to `@svayam/gov-operate` via the seam. Async
 * (dynamic import), so bin.ts routes it here instead of through sync `main`.
 */
export declare function runPluginCli(argv: readonly string[]): Promise<number>;
/**
 * The `gov` entry point. Returns a process exit code. `now` is injected (an
 * ISO-8601 instant) so the composition stays deterministic + testable.
 */
export declare function main(argv: readonly string[], now?: string): number;
