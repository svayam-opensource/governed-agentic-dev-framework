/**
 * The guided Operate flow (enterprise) — the same spirit as Work: get something
 * done fast. Pick an action → unit → env, and delegate to the `gov-operate`
 * plugin (`gov catalog/deploy/promote`). Pure over injected run + prompt/print.
 */
export interface OperateFlowDeps {
    readonly run: (argv: readonly string[]) => Promise<number> | number;
    readonly prompt: (q: string) => Promise<string>;
    readonly print: (l: string) => void;
}
export declare const OPERATE_ENVS: readonly ["dev", "uat", "prod"];
export declare function runOperateFlow(deps: OperateFlowDeps): Promise<number>;
