/**
 * Enterprise plugin seam — `gov` loads `@svayam/gov-operate` (catalog + deploy)
 * when it's installed and licensed. The OSS CLI stays free of enterprise code:
 * these commands dynamic-import the plugin and delegate to its `runCli` entry;
 * absent → a clear "install the enterprise plugin" message. The importer is
 * injected so the seam is fully unit-testable without the real package.
 */
import type { OrgConfig } from "../config/org-config.js";
/** The enterprise command namespace owned by the gov-operate plugin. */
export declare const PLUGIN_COMMANDS: readonly ["deploy", "catalog", "data", "promote", "rollback", "drift"];
export type PluginCommand = (typeof PLUGIN_COMMANDS)[number];
export declare function isPluginCommand(cmd: string): cmd is PluginCommand;
/** What `gov` hands the plugin so it can assemble its own ports. */
export interface PluginCliContext {
    readonly home: string;
    readonly config: OrgConfig;
    /** The enterprise license (from $GOV_LICENSE), if any. */
    readonly license?: string;
}
export interface PluginCliResult {
    readonly code: number;
    readonly lines: readonly string[];
}
/** The contract `@svayam/gov-operate` must export. */
export interface GovOperatePlugin {
    runCli(argv: readonly string[], ctx: PluginCliContext): Promise<PluginCliResult>;
}
export type PluginLoad = {
    readonly ok: true;
    readonly plugin: GovOperatePlugin;
} | {
    readonly ok: false;
    readonly message: string;
};
/** Dynamic-import the enterprise plugin. `importer` is injected for tests. */
export declare function loadGovOperate(importer?: (name: string) => Promise<unknown>): Promise<PluginLoad>;
/** Load the plugin and delegate the command; returns the plugin's exit code + output. */
export declare function runPluginCommand(argv: readonly string[], ctx: PluginCliContext, importer?: (name: string) => Promise<unknown>): Promise<PluginCliResult>;
