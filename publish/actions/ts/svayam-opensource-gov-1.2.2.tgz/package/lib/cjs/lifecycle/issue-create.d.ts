/**
 * `gov issue` — the verb for the step where governed work begins (#182, #194).
 *
 * Every stage of a project's life had a verb — seed, join, task, merge, pause,
 * resume, close — except the first. Writing down a unit of work happened in the
 * GitHub web UI, which is where two rules went to be forgotten:
 *
 *   · POL-413 — every board issue is assigned to the actor who created it. Enforced
 *     by memory, and by an auto-assign workflow each adopter has to remember to
 *     install.
 *   · An issue that is not ON a board is invisible to gov. Adding it is a second
 *     action, in a second place, after the browser has already moved on.
 *
 * Both become structural here: one command, assigned by construction, on the board
 * by construction.
 *
 * `--from <upstream-url>` is the same verb for the case where the reason for the
 * work is someone else's issue in a repository your organization cannot write
 * (#194). It creates YOUR issue, quoting theirs, and puts that on the board — so
 * the board item is something you can own, assign and close, which is what a board
 * item is for.
 *
 * Pure planning; the caller performs it. What is decided here is decidable in a test.
 */
import { type UpstreamIssue } from "./issue-mirror.js";
export interface IssuePlan {
    readonly repo: string;
    readonly title: string;
    readonly body: string;
    readonly assignee: string;
    /** Board number to add it to, or null when the caller named none and none is active. */
    readonly board: number | null;
    /** The upstream issue this mirrors, when it is one. */
    readonly mirrorOf: string | null;
}
export interface IssueRequest {
    readonly repo?: string;
    readonly title?: string;
    readonly body?: string;
    readonly from?: string;
    readonly board?: number | null;
    readonly assignee: string;
    readonly githubOrg: string;
    /** The default repo when none is named — normally the org's workspace repo. */
    readonly defaultRepo?: string;
}
export type IssuePlanResult = {
    readonly ok: true;
    readonly plan: IssuePlan;
} | {
    readonly ok: false;
    readonly message: string;
};
/**
 * Decide what to create. `fetchUpstream` is only consulted for `--from`, so the
 * ordinary path needs no network at all.
 */
export declare function planIssue(req: IssueRequest, fetchUpstream?: (repo: string, number: number) => UpstreamIssue | null): IssuePlanResult;
/** One line per thing that happened, in the order it happened. */
export declare function issueSummary(plan: IssuePlan, url: string, addedToBoard: boolean): readonly string[];
