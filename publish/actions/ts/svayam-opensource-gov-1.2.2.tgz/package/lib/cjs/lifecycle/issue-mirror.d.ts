/**
 * Mirroring an upstream issue into the repo you can actually write (#194, option E).
 *
 * `repo_overrides` sends the BRANCH to your fork while the board still links the
 * upstream issue. That works, and it leaves one thing crooked: the board item is
 * an issue in a repository your organization does not own, so assigning it, closing
 * it, or holding anyone to it are all things you cannot do. Under this model a
 * board item is a unit of work with an accountable owner (POL-413, POL-075) — and
 * an upstream issue can be a REASON for work without being able to be that.
 *
 * So: create your own issue, quoting theirs, and put that on the board. The
 * upstream one stays what it is — someone else's report, which you are free to
 * read and benefit from, exactly as the adopter asked:
 *
 *   > It would be helpful if I can see the issues raised in the parent and benefit
 *   > from problems being reported there, so that I can fix them in my own copy.
 *
 * The mirror is a link, not a copy of record. It quotes enough to work from and
 * points at the original for everything else, because two full copies of one
 * report drift apart and nothing reconciles them.
 */
/** What we read from the upstream issue. */
export interface UpstreamIssue {
    readonly repo: string;
    readonly number: number;
    readonly title: string;
    readonly body: string;
    readonly url: string;
    readonly state: string;
    readonly author: string | null;
}
/** `owner/repo#number` from an issue URL, or null. */
export declare function parseIssueUrl(url: string): {
    readonly repo: string;
    readonly number: number;
} | null;
/** The mirror's title — recognisable at a glance in a board column. */
export declare function mirrorTitle(up: UpstreamIssue): string;
/**
 * The mirror's body. Attribution first, then enough of the original to work from,
 * then the link. Never a silent copy: whoever opens this must be able to tell in
 * one line that the report is someone else's.
 */
export declare function mirrorBody(up: UpstreamIssue, opts?: {
    readonly maxQuote?: number;
}): string;
/** Refuse to mirror what does not need mirroring. */
export declare function mirrorPrecheck(up: {
    repo: string;
}, githubOrg: string): string | null;
