/**
 * The first project, made for you, so the first governed thing you do is read your
 * own policies (#186).
 *
 * Adoption ended with "review the seeded policies" and no way to do it that was not
 * either read-only (GitHub) or ungoverned (open the folder and edit). Both work.
 * Neither is the framework. The one route that demonstrates what was just installed
 * — a board, an issue, a project branch, a pull request — required the adopter to
 * assemble it by hand, on their first day, out of concepts they had not met yet.
 *
 * So it is assembled for them, and the work in it is the review they already need
 * to do. The starter project is not a toy: its issue is real, its branch is real,
 * and merging it is how the org's policies become the org's.
 *
 * Pure planning. The caller performs it, and may decline.
 */
export interface StarterProject {
    readonly boardTitle: string;
    readonly issueRepo: string;
    readonly issueTitle: string;
    readonly issueBody: string;
}
export declare function starterProject(githubOrg: string, workspaceRepo: string): StarterProject;
/** What was actually built, for the caller to report honestly. */
export interface StarterOutcome {
    readonly boardUrl: string | null;
    readonly issueUrl: string | null;
    readonly seeded: boolean;
}
export declare function starterSummary(o: StarterOutcome): readonly string[];
