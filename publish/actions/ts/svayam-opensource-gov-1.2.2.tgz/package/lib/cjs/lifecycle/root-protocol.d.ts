import type { Fs } from "./fs-io.js";
export declare function ensureRootProtocol(fs: Fs, projectDir: string, workspaceRepo: string): void;
