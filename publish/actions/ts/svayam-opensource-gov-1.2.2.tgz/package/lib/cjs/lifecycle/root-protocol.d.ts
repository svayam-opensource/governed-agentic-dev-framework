import type { Fs } from "./fs-io.js";
/**
 * Every agent's own path, mirrored into the project — ALL of them.
 *
 * This list had four entries, so `gemini`, `github-copilot` and `continue` were rendered into
 * the workspace and then placed nowhere the agent looks. Three of nine approved agents had
 * NOTHING in context, which the guarantee "the governance requirements are in the agent's
 * context" cannot survive. They were missing because the list was written when those three were
 * not yet in the catalog, and nothing tied the two together.
 *
 * DERIVED WOULD BE BETTER THAN LISTED. The paths are already declared per harness in
 * `agent/harness-manifest.yaml`; this is a second copy, and a second copy is what drifted.
 * Reading the manifest at runtime would need it shipped and parsed, so the list stays for now —
 * with a test asserting it covers every active harness, which is the part that was absent.
 */
export declare const ROOT_HARNESS_FILES: readonly ["AGENTS.md", "CLAUDE.md", "CONVENTIONS.md", ".clinerules/agent.md", ".cursor/rules/agent.mdc", ".gemini/styleguide.md", ".github/copilot-instructions.md", ".continue/rules.md", ".windsurf/rules/agent.md"];
export declare function ensureRootProtocol(fs: Fs, projectDir: string, workspaceRepo: string): void;
/**
 * Is the governance actually in this agent's context? — the check behind the guarantee.
 *
 * THE GUARANTEE IS ONLY WORTH THE VERIFICATION (Policy Owner, 2026-09-11, answering "1. should
 * be blocked"). gov promises the governance requirements are in the agent's context at launch
 * and on every turn, "from a file gov placed AND VERIFIED at the start of the session". Placing
 * it is `ensureRootProtocol`; this is the second half. Without it the promise rests on a copy
 * that may have been skipped — as `.clinerules` was, for as long as the mirror list named a
 * directory where the rendered file is `.clinerules/agent.md`. Nothing failed, and cline
 * launched into a governed project with no governance. That is the failure mode this exists for:
 * not a crash, a silence.
 *
 * Three ways the file can be there and not govern, all seen or reachable:
 *   missing  — never rendered for this workspace, or mirrored to the wrong path
 *   empty    — a truncated write, or a render that produced nothing
 *   unversioned — some other file of the same name, not gov's protocol
 *
 * The version marker is the discriminator. An adopter's own hand-written CLAUDE.md is a real
 * possibility, and overwriting it silently would be its own defect; refusing to launch names the
 * conflict instead.
 */
export type ContextVerdict = {
    readonly ok: true;
    readonly at: string;
} | {
    readonly ok: false;
    readonly at: string;
    readonly why: string;
};
/** The marker the renderer stamps into every harness file. Kept here, asserted by test against
 *  what `render-harness.mjs` actually writes, so the two cannot drift apart unnoticed. */
export declare const PROTOCOL_MARKER = "gov-protocol-version";
export declare function verifyAgentContext(fs: Pick<Fs, "readFile">, projectDir: string, harnessRel: string): ContextVerdict;
