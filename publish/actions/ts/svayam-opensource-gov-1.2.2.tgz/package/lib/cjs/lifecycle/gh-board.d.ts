import type { BoardRef } from "./identity.js";
import { type Board, type BoardProject } from "./board.js";
/** Runs `gh <args>` and returns stdout; throws on non-zero exit. */
export type RunGh = (args: string[]) => string;
/**
 * Build the projectV2 GraphQL query for a board ref, optionally from a cursor.
 *
 * NOTE (#148): this used to request `items(first: 50)` with no `pageInfo` and no
 * loop, so everything past the 50th board item was invisible — including entire
 * repositories, which made `task`/`merge`/`sync` silently skip them. Raising the
 * number is not a fix: 100 is GraphQL's per-page maximum, so the cliff would just
 * move. The caller must paginate; see {@link createGhBoard}.
 */
export declare function buildProjectQuery(ref: BoardRef, after?: string | null): string;
/** One page of a board: the project facts it carries, plus how to get the next. */
export interface BoardPage {
    project: BoardProject;
    hasNextPage: boolean;
    endCursor: string | null;
}
/**
 * Parse a `gh api graphql` projectV2 response into a BoardProject. The owner key
 * (organization|user) is whichever the query used, so we read the single value
 * under `data`. Throws {@link BoardFetchError} on missing project / bad payload.
 */
export declare function parseProjectPage(stdout: string): BoardPage;
/** The first page's project facts. Prefer {@link createGhBoard}, which paginates. */
export declare function parseProjectResponse(stdout: string): BoardProject;
/** Fold a later page into the accumulated board: counts sum, repo URLs union. */
export declare function mergeBoardPages(acc: BoardProject, next: BoardProject): BoardProject;
/** A {@link Board} backed by the `gh` CLI. `runGh` is injectable for tests. */
export declare function createGhBoard(runGh?: RunGh): Board;
