/**
 * Project identity derivation (SDD Part B, `seed`) — pure string logic, no I/O.
 *
 * Board-number scheme (POL-069): both the project id and its branch are keyed on
 * the GitHub Project BOARD NUMBER (no leading zero); they differ only by a
 * constant prefix. The board number IS the allocator — no `last_issued` counter,
 * no registry write (registry-elimination). id/branch are fully derived from the
 * board number + title:
 *   id      PRJ-<board#>-<slug>
 *   branch  BRNCH-<board#>-<slug>        (task branches: <branch>.ISSUE-<n>)
 *
 * A frozen legacy registry may still override the branch for ids that predate the
 * scheme; that lookup is injected (a `legacyBranches` map), keeping this module
 * free of YAML/registry I/O.
 */
export type OwnerField = "organization" | "user";
/** A parsed GitHub Project board URL. */
export interface BoardRef {
    readonly owner: string;
    readonly ownerField: OwnerField;
    readonly number: number;
}
/**
 * Parse a GitHub Project board URL into {owner, ownerField, number}, or null if
 * it isn't a recognizable board URL. Mirrors seed.sh:
 *   /orgs/<owner>/projects/<n>   → organization
 *   /users/<owner>/projects/<n>  → user
 */
export declare function parseBoardUrl(url: string): BoardRef | null;
/**
 * The human part of a board title — what it said before gov prefixed it.
 *
 * Strips REPEATEDLY. One pass left `PRJ-7 · PRJ-26 · Odd` deriving
 * `PRJ-26-prj-26-odd`, which is the same defect the strip exists to prevent, just needing two
 * prefixes instead of one. It costs a loop, and it means no amount of hand-prefixing can break
 * a board.
 */
export declare function titleWithoutProjectPrefix(title: string): string;
/**
 * The board title gov writes at seed: `PRJ-26 · Invoice API`.
 *
 * THE SEPARATOR IS DELIBERATE, and so is keeping the human half. The bare id would match the
 * docs exactly, and make a GitHub board list unreadable — a column of `PRJ-26-invoice-api`
 * entries is harder to scan than the words someone chose. The id answers "which project is this
 * in gov"; the title answers "what is it". Both fit.
 *
 * Idempotent: passing an already-prefixed title back returns the same string, because the human
 * part is recovered first.
 */
export declare function boardTitleFor(projectIdValue: string, currentTitle: string): string;
/**
 * Slugify a project title: lowercase, non-`[a-z0-9]` → `-`, collapse runs of `-`,
 * trim leading/trailing `-`. Byte-for-byte the behavior of lib.sh `slugify`, except that a
 * `PRJ-<n>` prefix gov wrote is stripped first so the operation is idempotent.
 * A title with no ASCII alphanumerics slugifies to "" (rejected by the caller).
 */
export declare function slugify(title: string): string;
/** Compose the project id from a board number + slug. */
export declare function projectId(boardNumber: number, slug: string): string;
/** Derive a branch from an id: `PRJ-<rest>` → `BRNCH-<rest>`; legacy → lowercase. */
export declare function deriveBranch(pid: string): string;
/** The branch for an id, honoring a frozen legacy override before deriving. */
export declare function branchForId(pid: string, legacyBranches?: Readonly<Record<string, string>>): string;
/** A task sub-branch off a project branch: `<branch>.ISSUE-<n>`. */
export declare function taskBranch(branch: string, issueNumber: number): string;
/** The result of deriving a project's identity from its board URL + title. */
export type IdentityResult = {
    readonly ok: true;
    readonly board: BoardRef;
    readonly projectId: string;
    readonly branch: string;
    readonly slug: string;
} | {
    readonly ok: false;
    readonly reason: "bad-url";
    readonly url: string;
} | {
    readonly ok: false;
    readonly reason: "empty-slug";
    readonly title: string;
};
/**
 * Derive a project's full identity (board ref + id + branch) from its board URL
 * and title. Rejects an unparseable URL and a title that slugifies to empty.
 */
export declare function deriveProjectIdentity(input: {
    url: string;
    title: string;
    legacyBranches?: Readonly<Record<string, string>>;
}): IdentityResult;
