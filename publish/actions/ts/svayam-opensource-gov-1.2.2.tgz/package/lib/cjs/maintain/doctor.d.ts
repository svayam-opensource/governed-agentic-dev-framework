import type { ResolveResult } from "../resolve/types.js";
export type DiagnosticStatus = "ok" | "warn" | "fail";
export interface Diagnostic {
    readonly name: string;
    readonly status: DiagnosticStatus;
    readonly detail: string;
}
export interface DoctorReport {
    /** True when nothing is a hard failure (warnings are allowed). */
    readonly ok: boolean;
    readonly diagnostics: readonly Diagnostic[];
}
/** The facts doctor inspects (gathered from the real environment by main()). */
export interface DoctorFacts {
    readonly gitPresent: boolean;
    readonly ghPresent: boolean;
    /**
     * Whether `gh` is SIGNED IN, which is a separate fact from being installed and
     * the commoner failure (#186): the tool installs cleanly and the person never
     * runs `gh auth login`, so every GitHub call fails later for a reason the
     * report did not mention. Undefined when `gh` is absent and the question does
     * not arise.
     */
    readonly ghAuthenticated?: boolean;
    /**
     * Scopes on the gh token, or null/undefined when unknown. Signed in is not the
     * same as sufficiently permitted (#186): `gh auth login` grants gh's own minimum,
     * which does not include `project` — and a Project board IS a project here.
     */
    readonly ghScopes?: readonly string[] | null;
    /**
     * Whether git knows who you are — `user.name` and `user.email`. Installed is not
     * the same as usable (#186): git refuses to commit without an identity, and gov
     * commits on every seed, task and merge. The failure surfaces several steps
     * later, inside a lifecycle command, as git's own "Please tell me who you are".
     */
    readonly gitIdentity?: {
        readonly name: string | null;
        readonly email: string | null;
    };
    readonly resolve: ResolveResult;
    readonly activeOrg: string | null;
    readonly cliVersion: string;
    /** Old-world artifacts found in the workspace (framework/, registry.yaml, …). */
    readonly staleArtifacts?: readonly string[];
    /** The workspace's content VERSION marker, or null. */
    readonly contentVersion?: string | null;
}
export declare function doctor(facts: DoctorFacts): DoctorReport;
/**
 * Render a report as printable lines.
 *
 * `color` is off by default so every caller that has not been told where it is writing keeps
 * plain text — and so the marks stay the meaning (#204). The mark is never dropped when the
 * colour is: a reader with NO_COLOR set must be able to tell a fail from an ok, and here that
 * distinction is the whole output.
 */
export declare function formatDoctorReport(report: DoctorReport, color?: boolean): string[];
