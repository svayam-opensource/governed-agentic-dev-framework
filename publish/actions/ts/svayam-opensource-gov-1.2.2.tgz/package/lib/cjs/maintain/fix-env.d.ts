/**
 * The token scopes gov actually needs, and why each one is on the list.
 *
 * `gh auth login` advertises "repo, read:org, admin:public_key" — gh's own minimum,
 * which knows nothing about what gov does with the token. The gap is not academic:
 * a GitHub Project board IS the project under this model (POL-044), and Projects
 * are behind their own `project` scope. A token that satisfies gh sails through the
 * sign-in and then fails at `gov seed`, several steps and some minutes later, on a
 * permission nobody mentioned.
 */
export declare const REQUIRED_SCOPES: readonly {
    readonly scope: string;
    readonly why: string;
}[];
/** Wanted, but gov works without it — so it is reported, never demanded. */
export declare const RECOMMENDED_SCOPES: readonly {
    readonly scope: string;
    readonly why: string;
}[];
/**
 * Pull the granted scopes out of `gh auth status` output. Returns null when the
 * line is absent, which means "could not tell" — reported as unknown rather than
 * as missing, because a false alarm about permissions sends people to their
 * administrator for nothing.
 */
export declare function parseGrantedScopes(ghAuthStatus: string): readonly string[] | null;
/** Which required scopes are absent. `repo` implies its children, e.g. `public_repo`. */
export declare function missingScopes(granted: readonly string[]): readonly {
    readonly scope: string;
    readonly why: string;
}[];
/** The system package managers we know how to drive. */
export type PackageManager = "brew" | "apt" | "dnf" | "yum" | "apk" | "pacman" | "zypper" | "winget";
/** One remediation: what it fixes, the exact command, and how it must be run. */
export interface FixStep {
    /** The diagnostic this step clears — matches the doctor's row name. */
    readonly fixes: string;
    /** One line a non-specialist can read before consenting. */
    readonly what: string;
    /**
     * What is missing and what it is FOR, in the reader's terms — not the command's.
     * Consent to "sudo dnf install -y gh" is not informed consent; consent to "you do
     * not have gh, and gov needs it to sign you in to GitHub" is.
     */
    readonly why: string;
    readonly command: readonly string[];
    /** True when the command needs elevation. We never add `sudo` ourselves — see planFixes. */
    readonly sudo: boolean;
    /** True when the command talks to the user (a browser login) and must inherit the terminal. */
    readonly interactive: boolean;
    /**
     * The `fixes` keys that must all succeed first. A dependent step is skipped when
     * any prerequisite failed — otherwise `gh auth login` runs after the `gh` install
     * failed and reports `ENOENT`, which reads as a second, unrelated fault.
     */
    readonly dependsOn?: readonly string[];
}
export interface FixPlan {
    readonly steps: readonly FixStep[];
    /** Things that are wrong but that no command here can fix, each with what to do instead. */
    readonly manual: readonly string[];
}
/** What the planner needs to know about the machine. */
export interface EnvFacts {
    readonly gitPresent: boolean;
    readonly ghPresent: boolean;
    readonly ghAuthenticated: boolean;
    readonly platform: string;
    /**
     * The distribution id from /etc/os-release (`fedora`, `rocky`, `rhel`, `ubuntu`,
     * …), lowercased, or null off Linux. The package manager alone is not enough to
     * decide anything: Fedora and Rocky both use `dnf`, but Fedora ships the GitHub
     * CLI in its own repositories and Rocky does not.
     */
    readonly osId?: string | null;
    /**
     * Scopes on the current gh token, or null when `gh` is absent or the status
     * could not be read. Null is "unknown", not "none".
     */
    readonly ghScopes?: readonly string[] | null;
    /** git's configured identity. Missing values are as blocking as a missing git. */
    readonly gitIdentity?: {
        readonly name: string | null;
        readonly email: string | null;
    };
}
export declare function detectPackageManager(hasTool: (name: string) => boolean): PackageManager | null;
/**
 * Build the ordered plan. Order is not cosmetic: `gh` must exist before
 * `gh auth login` can run, so an unauthenticated-and-missing `gh` yields two
 * steps in that sequence.
 */
export declare function planFixes(facts: EnvFacts, pm: PackageManager | null): FixPlan;
/** Render a step the way it must be typed, so consent is informed. */
export declare function renderCommand(step: FixStep): string;
/**
 * The consent screen: what is missing, in the reader's terms, before a single
 * command is named.
 *
 * The first version led with the commands — "These commands will fix what is
 * missing:" followed by four `sudo` lines. A reader who does not already know what
 * `gh` is cannot consent to installing it; they can only agree or give up. State
 * the gap and its purpose first; the commands are the appendix, not the argument.
 */
export declare function formatPlanNarrative(plan: FixPlan, color?: boolean): string[];
export declare function formatPlan(plan: FixPlan): string[];
