/**
 * Where the work happens, when that is not where the issue lives (#194).
 *
 * A board links an issue; `seed` takes that issue's repository as a participating
 * repo and cuts the project branch there (POL-044 — repos come from the board).
 * That is right until the issue is upstream of a fork:
 *
 *     genevaers/Workbench      the issue's home — readable, not writable
 *             │ fork
 *             ▼
 *     svm-geneva/Workbench     the adopter's own — where the work can happen
 *
 * Two facts gov had collapsed into one. Where the REASON for the work is recorded
 * and where the WORK happens need not be the same repository, and nothing in the
 * governance model says they must: the branch, the worktree, the pull request and
 * the merge all belong to the writable one.
 *
 * The mapping is DECLARED, never inferred. Resolving a fork automatically — "no
 * write access, and a fork exists under your org, so use it" — would decide where
 * someone's code is pushed without being told, and would guess when there are
 * several forks or the fork is stale. It lives in `org-config.yaml`, so it is
 * reviewed like any other governance change and everyone in the org sees the same
 * answer:
 *
 *     repo_overrides:
 *       genevaers/Workbench: svm-geneva/Workbench
 */
/** `owner/repo` → `owner/repo`. Both sides are slugs, never URLs. */
export type RepoOverrides = Readonly<Record<string, string>>;
/** `owner/repo` from any GitHub URL form, or null when it is not one. */
export declare function repoSlugFromUrl(url: string): string | null;
/**
 * Read the `repo_overrides:` block. A nested map of `owner/repo: owner/repo`,
 * ended by the first line that is not indented.
 */
export declare function parseRepoOverrides(text: string): RepoOverrides;
/**
 * Apply the map to a repo URL. Returns the URL unchanged when nothing matches —
 * the common case, and the one that must stay free of surprises.
 */
export declare function resolveWorkRepo(url: string, overrides: RepoOverrides): string;
/** The redirects actually used on this run — said out loud, because they are decisions made for you. */
export declare function appliedOverrides(urls: readonly string[], overrides: RepoOverrides): readonly {
    readonly from: string;
    readonly to: string;
}[];
/**
 * Add mappings to an `org-config.yaml`, creating the block if it is absent (#194).
 *
 * WRITTEN, NOT PRINTED FOR COPYING. The preflight already found the fork; asking
 * someone to retype what the tool worked out is busywork, and it is not what made
 * option B the right answer. What made it right is that the mapping is CONSENTED
 * and RECORDED — reviewable in the org's own config, the same as any other
 * governance value. Consent is the prompt; the recording is this function. Neither
 * requires a human to act as a transcription service.
 *
 * Returns the new text, or null when there was nothing to add.
 */
export declare function withRepoOverrides(text: string, additions: readonly {
    readonly from: string;
    readonly to: string;
}[]): string | null;
