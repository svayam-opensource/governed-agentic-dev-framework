/**
 * The approved-agent list, read from and written to `llm-governance.md` (#196).
 *
 * WHY A FENCED BLOCK AND NOT THE PROSE TABLE. The policy shipped as a markdown
 * table maintained by hand, and gov read it with a forgiving parser — which means
 * "sometimes wrong", about a C01 list. A heading someone rewords, or a provider
 * named in a passing sentence, and gov silently governs by a different set than the
 * one the Infrastructure Owner approved.
 *
 * WHY INSIDE THE POLICY AND NOT BESIDE IT. A separate `approved-agents.yaml` parses
 * more cleanly and is a second copy of one fact — the shape this project has now
 * written four guards against (registry.yaml against GitHub, ADOPTER_DIRS against
 * MANIFEST.yaml, package.json against content/VERSION, the itinerary against the
 * checklist). One document: the table stays for humans, the block is what gov reads,
 * and both are approved together by the owner CODEOWNERS names.
 *
 * WHY NOT `org-config.yaml`. That file holds an organization's VALUES. This is a
 * governed decision with an owner and a review path, and it belongs where the
 * review path is.
 */
/** One approved agent. `id` matches the harness manifest, which is what makes it checkable. */
export interface ApprovedAgent {
    readonly id: string;
    readonly default?: boolean;
}
/**
 * Read the block. Null means "no block" — distinct from an empty list, because one
 * says the org has not decided and the other says it decided on nothing.
 */
export declare function parseApprovedAgents(policyText: string | null): readonly ApprovedAgent[] | null;
/**
 * The agent to use without asking: the one marked `default`, or the only one there
 * is. More than one and none marked → null, and the caller asks.
 */
export declare function defaultAgent(approved: readonly ApprovedAgent[] | null): string | null;
/** Render the block. Kept minimal — a human reads the table above it, not this. */
export declare function renderApprovedAgents(agents: readonly ApprovedAgent[]): string;
/**
 * Write the block into the policy, replacing an existing one or inserting it under
 * the Approved heading. Returns the new text, or null when nothing would change.
 *
 * Never appended blindly: a second block would be a second answer, and the parser
 * would take whichever came first.
 */
export declare function withApprovedAgents(policyText: string, agents: readonly ApprovedAgent[]): string | null;
