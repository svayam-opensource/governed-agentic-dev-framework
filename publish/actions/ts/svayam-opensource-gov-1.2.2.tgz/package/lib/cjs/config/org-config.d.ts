export interface OrgConfig {
    readonly orgName: string;
    readonly orgShortName: string;
    readonly orgSlug: string;
    readonly orgSlugLower: string;
    readonly githubOrg: string;
    readonly workspaceRepo: string;
    /** `org_repo_url` — the gov repo clone URL (used by join). */
    readonly orgRepoUrl: string;
    readonly defaultBranch: string;
    readonly defaultCodeBranch: string;
    /**
     * `env_branches` — the env branches BETWEEN `default_branch` and `default_code_branch`, HIGHEST FIRST
     * (e.g. `[uat]`, or `[uat, sit]`). Absent → the two-rung ladder, which is what every adopter has before
     * they configure anything.
     *
     * Read by `close`, which must land a project branch in its base and then every branch below it — a HOTFIX
     * is cut from a higher env branch and has to reach both (adr-hotfix-release-line, PRJ-43).
     *
     * DELIBERATELY A SECOND COPY of something the deploy side also knows. `deploy-policy.yaml`'s `promotion:`
     * graph describes what may ADVANCE INTO what, with fan-out (`dev → [sit, uat]`); this is an ORDER to merge
     * in. A graph with fan-out has no single order, so deriving one here would mean gov-work picking a path
     * and calling it the answer. Two clients, two questions, one written down in each place — recorded here so
     * the duplication is a decision rather than something a later reader has to guess at (rkant, 2026-08-09).
     */
    readonly envBranches: readonly string[];
    /**
     * `repo_overrides` — where the WORK happens, when that is not where the issue
     * lives (#194). `owner/repo: owner/repo`, upstream on the left, the repo this org
     * can write on the right. Empty for every org that does not work from forks.
     */
    readonly repoOverrides: Readonly<Record<string, string>>;
    /** `agent_work_root`, expanded to an absolute path. */
    readonly agentWorkRoot: string;
    /** `gov_workspace`, expanded to an absolute path. */
    readonly govWorkspace: string;
    readonly policyOwnerEmail: string;
    /** OpenBao/Vault address (`vault_addr` or `services.vault`) — read by the DEPLOY clients (gov-cicd/gov-infra);
     *  gov-work stores no secrets. env `GOV_BAO_ADDR` overrides. */
    readonly vaultAddr: string;
    /** IAM broker OIDC base (`services.oidc`) — the deploy clients' `auth login` target. gov-work never uses it. */
    readonly oidcBase: string;
    /** The org service endpoints (`services:` block) as a generic map — vault/oidc used by core, jenkins/npm/
     *  docker read by the gov-cicd plugin. Org-level, governed; adopters inherit them. */
    readonly services: Readonly<Record<string, string>>;
    /** Gov tenant/account (`gov_account`) — the account context service auth mints under; env `GOV_ACCOUNT` overrides. */
    readonly govAccount: string;
    /** Token → value for tool-file substitution (seed phase B.1). */
    readonly orgTokens: Readonly<Record<string, string>>;
}
export declare function parseOrgConfig(text: string, home?: string): OrgConfig;
