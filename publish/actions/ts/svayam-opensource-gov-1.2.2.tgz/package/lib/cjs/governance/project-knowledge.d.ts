/**
 * POL-408 front matter for PROJECT knowledge — `projects/<id>/knowledge/**.md`.
 *
 * `checkKnowledge` validates the ORG tree (`knowledge/**`) and always has. Project knowledge was never
 * scanned by anything, which surfaced on 2026-08-07 in the plainest possible way: a markdown formatter
 * destroyed a doc's front matter — turning `domain: development` into an `##` heading and deleting the
 * closing `---` — and `gov validate` reported PASS. A requirement nothing checks is a convention, and this
 * one had been resting on care for months.
 *
 * ## Why this checks CHANGED files only
 *
 * Measured before writing it: 221 project knowledge docs, **16 compliant**. 152 carry no front matter at
 * all and 53 have invalid fields, across projects that closed long ago. Validating all of them would fail
 * every push and every close gate in the repository — a check nobody can satisfy is switched off within the
 * week, and we would be back to no check at all.
 *
 * So the scope is the Policy Owner's own rule: knowledge docs are **born compliant, not retrofitted**. A doc
 * you touch must be valid; a doc you did not touch is history. `ctx.changedFiles` carries the scope — when
 * it is absent (a plain `gov validate` with no diff) this validator passes silently rather than guessing,
 * because inventing a scope would make the result depend on where it ran.
 *
 * A retrofit sweep of the other 205 is a separate, deliberate act. This makes the number stop growing.
 */
import type { ValidateContext, ValidationResult } from "./validate.js";
/** Is this a project knowledge doc this validator governs? */
export declare function isProjectDoc(rel: string): boolean;
/** The POL-408 errors in one doc's text, `[]` when it is valid. Pure — the file list and the reading are
 *  the caller's, so this is testable on a string. */
export declare function pol408Errors(rel: string, text: string): string[];
export declare function checkProjectKnowledge(ctx: ValidateContext): ValidationResult;
