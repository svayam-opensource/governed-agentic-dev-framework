/** Governance (SDD Part C): the validation suite (+ session-gate, to come). */
export * from "./validate.js";
export * from "./version-sync.js";
export * from "./secrets.js";
export * from "./protocol.js";
export * from "./knowledge.js";
export * from "./privacy.js";
export * from "./suite.js";
export * from "./session-gate.js";
export { checkProjectKnowledge, pol408Errors, isProjectDoc } from "./project-knowledge.js";
