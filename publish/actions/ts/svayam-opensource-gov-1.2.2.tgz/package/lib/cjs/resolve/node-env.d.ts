import type { ResolveEnv } from "./types.js";
/** Expand a leading `~` / `~/…` against `$HOME` (matches the bash pointer read). */
export declare function expandTilde(p: string, home?: string): string;
/**
 * The OS-idiomatic per-user config dir holding the CLI-local registry
 * (`gov-workspaces` + `active-org`). Windows → `%APPDATA%\prj`; elsewhere →
 * `$XDG_CONFIG_HOME/prj` or `~/.config/prj`. The `prj` leaf is kept for
 * continuity with existing registries (shared multi-home store). Pure — env /
 * platform / home are injectable for tests.
 */
export declare function configDir(env?: NodeJS.ProcessEnv, platform?: NodeJS.Platform, home?: string): string;
/**
 * The registry directory — `~/.gov` on every platform (workspace-resolution contract R10).
 *
 * DELIBERATELY NOT OS-IDIOMATIC, unlike {@link configDir}. R10 requires ONE location that every client
 * reads: if `gov` looks in `~/.gov` while another looks in `%APPDATA%\prj`, the two report different
 * ACTIVE ORGS — the same divergence `svm-prj-work#310` exists to end, one level down and harder to see.
 * A per-platform answer cannot satisfy "one location", so the contract picks home-relative and every
 * client complies.
 *
 * `${XDG_CONFIG_HOME:-~/.config}/prj/` is the legacy location — named after the RETIRED `prj` CLI. It is
 * read for migration and never written; see {@link legacyRegistryFiles}.
 */
export declare function govRegistryDir(home?: string, platform?: NodeJS.Platform): string;
/** The canonical registry files (R10). */
export declare function registryFiles(home?: string, platform?: NodeJS.Platform): {
    readonly workspaces: string;
    readonly active: string;
};
/** Where a pre-R10 install kept the same two facts. Read-only: migrated from, never written to. */
export declare function legacyRegistryFiles(env?: NodeJS.ProcessEnv, platform?: NodeJS.Platform, home?: string): {
    readonly workspaces: string;
    readonly active: string;
};
/**
 * Carry a pre-R10 registry forward to `~/.gov/`, once per process.
 *
 * MUST run wherever the registry is READ, not only where it is written. The registry has two readers —
 * the resolver ({@link createNodeEnv}) and the store — and migrating in only one means a command that
 * merely resolves (`gov doctor`, and every governance read) sees an empty registry and hard-fails
 * `no-active-org` on a machine that worked before the upgrade. Found exactly that way.
 *
 * Copies, never moves: the legacy files stay so a downgrade still works. Only ever writes when the
 * canonical location is absent, so it cannot overwrite anything current. Failure is swallowed — a
 * migration that cannot write must not break the command, and the legacy files remain to retry from.
 */
export declare function ensureRegistryMigrated(home?: string, platform?: NodeJS.Platform, env?: NodeJS.ProcessEnv): void;
/** Test seam: forget that migration ran, so a fresh fixture is not skipped. */
export declare function resetRegistryMigrationForTests(): void;
/** True if `p` sits inside a `.bases/` base clone (never a real gov home). */
export declare function containsBasesSegment(p: string): boolean;
/**
 * Extract a TOP-LEVEL scalar (`key: value`) from YAML text. Deliberately tiny —
 * only what the resolver needs (`github_org`, `gov_workspace`), mirroring what
 * the bash `yq` / `python3` one-liners return for a simple string field. Ignores
 * indented keys; tolerates single/double quotes and trailing `#` comments on
 * unquoted values.
 */
export declare function readTopLevelScalar(text: string, key: string): string | null;
/** Options for the Node adapter (all overridable for tests). */
export interface NodeEnvOptions {
    readonly cwd?: string;
    readonly configDir?: string;
    readonly home?: string;
}
/** Build a read-only, filesystem-backed `ResolveEnv`. */
export declare function createNodeEnv(opts?: NodeEnvOptions): ResolveEnv;
