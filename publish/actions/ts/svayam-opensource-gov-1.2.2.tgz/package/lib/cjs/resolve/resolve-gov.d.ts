/**
 * `prjResolveGov` — the deterministic governance-home resolver (SDD-013 / SDD-040).
 *
 * active-org is the anchor; cwd-walk is a cross-check (see types.ts for the full
 * decision table). The function is PURE — it only reads through `ResolveEnv` and
 * never writes, so resolution cannot pollute the registry.
 */
import type { ResolveEnv, ResolveResult } from "./types.js";
/**
 * Which of the two things `gov_repo` used to mean does this command need?
 * (workspace-resolution-contract.md D3 — `svm-prj-work#310`.)
 */
export type OperationClass = "GOVERNANCE" | "PROJECT" | "MACHINE"
/**
 * Legacy, and the DEFAULT: cwd if we are standing in a workspace, else the registry.
 *
 * Not a contract class — the contract governs which repository an OPERATION ACTS ON. Reporting is a
 * different question: `gov doctor` and the context banner must describe wherever you actually are,
 * including from outside any project, and answer rather than refuse. Making PROJECT the default broke
 * exactly that, and the hermetic adopter smoke caught it.
 *
 * Every verb should name its class; until each does, this preserves today's behaviour.
 */
 | "REPORT";
export declare function prjResolveGov(env: ResolveEnv, opClass?: OperationClass): ResolveResult;
/** Render a resolution failure as an actionable one-line CLI message. */
export declare function resolveFailureMessage(r: Extract<ResolveResult, {
    ok: false;
}>): string;
