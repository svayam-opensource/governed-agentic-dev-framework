/**
 * Answer validation for interactive prompts (#192).
 *
 * Every prompt used to have two outcomes: an answer it accepted, or an exit. A
 * typo, an org you cannot write to, a repo name already taken — each ended the
 * command and sent the adopter back to the shell to start over, sometimes minutes
 * in.
 *
 * There should be three, and the third is the one that was missing:
 *
 *     accept  → carry on
 *     reject  → say what is wrong with THAT value, and ask again
 *     Ctrl-C  → the user's own way out, which they already know
 *
 * QUITTING IS THE USER'S DECISION. Ctrl-C is universal, always available and
 * unambiguous. A tool that exits on someone's behalf because they mistyped is
 * deciding something that was never its to decide.
 *
 * A validator returns null when the value is good, or the sentence to show when it
 * is not. The sentence is about the VALUE — "an org slug is 2-6 letters or digits;
 * 'GENEVA-1' has a dash" — not about the field, because the reader already knows
 * what the field is; they just got it wrong.
 */
/** null = accepted. A string = why not, phrased for the person who typed it. */
export type Validator = (value: string) => string | null;
export declare const nonEmpty: (what: string) => Validator;
/**
 * 2–6 letters or digits. It decides `~/.gov/<slug>/`, so a character git or a
 * filesystem would argue about is not a preference we can honour.
 */
export declare const orgSlug: Validator;
/** Shape only. Whether the address can DO anything is a separate question. */
export declare const emailShape: Validator;
export declare const isoDate: Validator;
/** `<org>/<repo>` — a name to CREATE, not a URL to clone. */
export declare const orgRepoTarget: Validator;
/**
 * The workspace's default branch. Only two answers mean anything, so it is a
 * choice rather than free text: a typo here produces a branch name the rest of the
 * tool will look for and never find.
 */
export declare const BRANCH_CHOICES: readonly {
    readonly key: string;
    readonly branch: string;
}[];
export declare function parseBranchChoice(v: string): string | null;
export declare const branchChoice: Validator;
/** A git branch name for day-to-day development in code repos. Anything git accepts. */
export declare const branchName: Validator;
