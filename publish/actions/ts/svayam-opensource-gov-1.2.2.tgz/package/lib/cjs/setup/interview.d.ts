/**
 * The adopter's org interview — ONE uninterrupted run of questions, then the work.
 *
 * WHY THIS EXISTS AS ITS OWN STEP. The questions used to be split across three
 * places: two in `foundNewOrg` (organization, repository name), one in
 * `runCreateWorkspace` (the slug), and six more in `runSetup` — with the repository
 * CREATED AND CLONED in the middle of that sequence. An adopter was therefore asked
 * to name a repository, watched it be created, and was then asked six further
 * questions about an organization whose repository already existed. The irreversible
 * act sat in the middle of the reversible ones.
 *
 * Everything here is asked BEFORE anything is created. Until the last answer is in,
 * Ctrl-C costs nothing and leaves nothing behind — which is the property the old
 * order quietly gave away. It also means the answers can be shown back as one block,
 * because by then they are all known.
 *
 * THE ONE CONCESSION TO ORDER (#197). The probe that asks "does this organization
 * already have a governance repository?" needs the organization, and diverting to
 * the joiner path makes every later question pointless. It therefore runs the
 * instant Q3 is answered — the earliest moment it can — which costs two answered
 * questions (the two names) in the case where the adopter should have been joining.
 * Two questions is the price of asking for the human-readable name first; the
 * alternative is opening with a GitHub org id, which is not how anyone describes
 * their own organization.
 */
import type { OrgConfigValues } from "./setup.js";
import type { ApprovedAgent } from "../config/approved-agents.js";
/** Thrown when a prompt cannot get a usable answer — never on a human's typo. */
export declare class InterviewRefused extends Error {
}
export interface InterviewIo {
    /** Ask with a default; return the answer (default when blank). */
    readonly prompt: (question: string, def: string) => Promise<string>;
    readonly print: (line: string) => void;
    /** Derive the full config from what has been answered so far — supplies each default. */
    readonly derive: (partial: Partial<OrgConfigValues>) => OrgConfigValues;
    /**
     * Runs the moment the GitHub organization is known, before any further question.
     * Return false to abandon the interview (the caller has taken over — e.g. diverted
     * to the joiner path). Absent means "carry on".
     */
    readonly afterOrg?: (org: string) => Promise<boolean> | boolean;
    /**
     * Organizations the signed-in GitHub account belongs to, offered at Q3 as a numbered list.
     * A convenience, never a gate — see `org-choice.ts`.
     */
    readonly myOrgs?: () => readonly string[];
    /** Ask the agent-approval question (Q10). Absent = do not ask; the caller asks elsewhere. */
    readonly selectAgents?: boolean;
    readonly color?: boolean;
}
/**
 * Everything the adopter answered, in the shape the setup flow takes it.
 *
 * `agents` rides along with the org-config values because the only place the approved list can
 * be written AND still be committed is inside `createWorkspace` — see the note in main.ts. It
 * is not an org-config key, hence its own type rather than a cast at the call site.
 */
export type SetupPreAnswers = Partial<OrgConfigValues> & {
    readonly agents?: readonly ApprovedAgent[];
};
export interface InterviewResult {
    /** The GitHub organization (Q3). */
    readonly org: string;
    /**
     * The organization's approved agents (Q10), first one default.
     *
     * IN THE INTERVIEW, not after the repository exists. It used to be asked once the clone had
     * landed, which put the single most consequential policy answer in adoption AFTER the point
     * of no return — and left it out of the block that reads every other answer back.
     */
    readonly agents?: readonly ApprovedAgent[];
    /** The governance repository to create (Q4). */
    readonly repo: string;
    /** Every answer, keyed as org-config values, ready to hand to `runSetup` as `existing`. */
    readonly answers: Partial<OrgConfigValues>;
}
/**
 * The opening block. Numbered because it makes three separate promises — a repository
 * WILL be created, here is what it is for, and here is why the next few minutes are
 * questions — and prose ran them together into something adopters skipped.
 */
export declare const INTERVIEW_HEADER: readonly string[];
export interface InterviewOutcome {
    readonly repoUrl: string;
    readonly localPath: string;
    readonly configUrl: string;
    readonly projectsPath: string;
}
/**
 * The closing block. Every line names something that now EXISTS, with the address to
 * reach it — because the questions above were abstract and this is the only place the
 * adopter learns where their answers went.
 */
export declare function interviewSummary(o: InterviewOutcome): readonly string[];
/**
 * Run the nine questions in order. Returns null when `afterOrg` took over.
 *
 * Each default is re-derived from the answers so far, so Q2 can suggest a short name
 * built from Q1's legal name and Q5 can suggest a slug built from Q3's organization.
 * Offering an empty default and then refusing empty is a question that answers itself
 * wrongly (#210).
 */
export declare function askOrgInterview(io: InterviewIo): Promise<InterviewResult | null>;
