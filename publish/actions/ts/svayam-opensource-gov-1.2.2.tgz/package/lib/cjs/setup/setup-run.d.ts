import type { Fs } from "../lifecycle/fs-io.js";
import { type OrgConfigValues } from "./setup.js";
export interface SetupIo {
    readonly fs: Fs;
    readonly cwd: string;
    readonly originUrl: string;
    readonly ghUser: string | null;
    readonly gitEmail: string | null;
    readonly today: string;
    readonly existing?: Partial<OrgConfigValues>;
    /**
     * Did the org interview already ask everything (adopter path)? Set ONLY by that path.
     *
     * It cannot be inferred from `existing` being populated: a bare `gov setup` re-run in
     * a configured repo populates `existing` too, and there the values are DEFAULTS to be
     * offered, not answers to be skipped. Conflating the two would silently turn
     * reconfiguration into a no-op.
     */
    readonly interviewed?: boolean;
    /** Ask a question with a default; return the answer (default if blank). Injected. */
    readonly prompt: (question: string, def: string) => Promise<string>;
    readonly print: (line: string) => void;
    /** Configure the origin remote (git remote set-url/add). Optional. */
    readonly setOriginRemote?: (url: string) => void;
}
/**
 * NOTE (#159 finding 4, client-configuration-contract R1): setup no longer asks for Vault, OIDC or the
 * governance account id. `gov` reads none of them — they belong to `gov-cicd`/`gov-infra`, and asking
 * the free work-tier adopter about modules they have not adopted is the defect. The keys are still
 * READ when present, so existing workspaces are unaffected; they are simply no longer prompted for.
 */
/** Thrown when a prompt cannot get a usable answer — never on a human's typo. */
export declare class AnswerRefused extends Error {
}
export declare function runSetup(io: SetupIo, interactive: boolean): Promise<number>;
