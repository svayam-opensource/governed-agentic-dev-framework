/**
 * `gov setup <org>/<repo>` — CREATE a governed workspace from nothing (#159).
 *
 * Adoption used to be four manual steps before the tool did anything: create from the template in the
 * GitHub UI, `npm i -g`, `git clone`, `cd`, then `gov setup`. Two of them are where adopters got lost —
 * *which* repo to clone, and *which* directory setup must run in.
 *
 * ONE VERB, AND THE ARGUMENT DECIDES. `gov setup <org>/<repo>` creates; bare `gov setup` configures the
 * workspace you are in, exactly as before; `--non-interactive` never creates whatever the cwd. Creation
 * can never be inferred from location, so a re-run cannot be mistaken for "make me a new one".
 *
 * NOTHING IS CREATED UNTIL EVERYTHING IS KNOWN. `gh` cannot delete a repository without the `delete_repo`
 * scope, which a normal `gh auth login` does not grant — so a half-made repo in someone's GitHub org
 * cannot be rolled back, and requiring adopters to hand a setup command repo-deletion rights is a bad
 * trade. The window is shrunk instead of undone: every precondition is checked and the org slug is known
 * before the first remote call. See `preflight`.
 *
 * Locations are DERIVED, per the workspace-resolution contract (R9/R10), not chosen per machine:
 *   registry   ~/.gov/workspaces · ~/.gov/active
 *   mirror     ~/.gov/<org_slug>/gov_repo
 *   work root  ~/.gov/<org_slug>/projects
 * `--path` overrides the mirror location only; the registry records the override, and resolution reads
 * the registry either way, so R2 is unaffected.
 */
/** The GitHub coordinates of the repo to create. */
export interface CreateTarget {
    readonly org: string;
    readonly repo: string;
}
/** Everything this module touches, injected so the logic is testable without a network or a filesystem. */
export interface CreateIo {
    /** run `gh` with args; return stdout, or null when it exits non-zero. */
    readonly gh: (args: readonly string[]) => string | null;
    /** absolute path of the user's home directory. */
    readonly home: string;
    /** does this path exist? */
    readonly exists: (p: string) => boolean;
    readonly print: (line: string) => void;
}
export type PreflightFailure = 
/** the argument was not `<org>/<repo>`. */
{
    readonly why: "bad-target";
    readonly got: string;
}
/** `gh` is not authenticated at all. */
 | {
    readonly why: "not-authenticated";
}
/** authenticated, but cannot create a repository in that org. */
 | {
    readonly why: "cannot-create";
    readonly org: string;
}
/** the org ALREADY has a governance repo — creating a second forks the org's policy. */
 | {
    readonly why: "already-governed";
    readonly repo: string;
    readonly all: readonly string[];
}
/** something is already at the derived (or --path) location. */
 | {
    readonly why: "path-occupied";
    readonly path: string;
}
/** the governance probe could not run — refusing rather than risking a duplicate. */
 | {
    readonly why: "cannot-verify";
    readonly org: string;
};
/** Non-fatal findings. The command proceeds; the adopter is told. */
export interface PreflightWarning {
    readonly what: "no-project-scope" | "cannot-protect-branch" | "governance-scan-truncated";
    readonly detail: string;
}
/**
 * `<org>/<repo>` and nothing else.
 *
 * Deliberately strict: a URL, an `owner/repo/extra`, or a bare name are all things a hurried adopter
 * types, and each would otherwise create a repo somewhere unintended. GitHub's own rules — alphanumerics,
 * `-`, `_`, `.` — are the whole permitted set.
 */
export declare function parseTarget(arg: string): CreateTarget | null;
/** The org's canonical locations (R9). `slug` is the answer to "Org slug", lowercased. */
export declare function derivedPaths(home: string, slug: string): {
    readonly govRepo: string;
    readonly workRoot: string;
    readonly registry: string;
    readonly active: string;
};
/** A repo name an adopter need not invent. */
export declare const suggestRepoName: (slug: string) => string;
/**
 * Does this GitHub org already have a governance repo?
 *
 * THE FAILURE THIS PREVENTS IS THE FRAMEWORK'S WORST. A second developer at an adopting org who runs
 * create — and they are, by definition, new — would make a SECOND governance repo, and the org's policy
 * forks silently. Nothing downstream would notice: both repos validate, both resolve, and two halves of
 * one org would govern themselves differently.
 *
 * Searched by content rather than by name, because the name is exactly what a second adopter would pick
 * differently.
 */
export declare function findExistingGovernanceRepo(io: CreateIo, org: string): {
    readonly repos: readonly string[];
    readonly truncated: boolean;
    readonly verified: boolean;
};
/**
 * Wait for GitHub to finish copying the template before cloning it.
 *
 * `gh repo create --template` RETURNS BEFORE THE COPY COMPLETES. Cloning immediately yields
 * `warning: You appear to have cloned an empty repository` — and setup then configures nothing, while
 * appearing to succeed. Observed on the first real adoption run: the remote ended up with 16 files, the
 * adopter's clone with none.
 *
 * Same read-after-write shape as the npm publish verification (`910-GOV-CICD#132`): the write succeeded,
 * the immediate read did not see it, and the code believed the read.
 */
export declare function waitForTemplateContent(io: CreateIo, target: CreateTarget, attempts?: number, sleep?: (ms: number) => void): boolean;
/**
 * Everything that must be true BEFORE anything is created.
 *
 * Hard-fails only on what makes the command impossible — no auth, no create permission, an occupied
 * path, or an org that is already governed. Everything else warns and continues: `project` scope will
 * matter (GitHub Projects are the source of truth) but not until `gov seed`, and branch protection is
 * unavailable on private repos under some plans, which must not stop an adoption.
 */
export declare function preflight(io: CreateIo, rawTarget: string, slug: string, pathOverride?: string): {
    readonly ok: false;
    readonly failure: PreflightFailure;
} | {
    readonly ok: true;
    readonly target: CreateTarget;
    readonly govRepo: string;
    readonly warnings: readonly PreflightWarning[];
};
/** What a preflight failure should say. Every message names the next action, not just the problem. */
export declare function explainFailure(f: PreflightFailure): readonly string[];
/**
 * Publisher scaffolding that must not reach an adopter (#159 finding 6c).
 *
 * The framework repo is also the template, so `gh repo create --template` copies EVERYTHING the
 * publisher needs to build and test itself. An adopter has no TypeScript to build and no framework to
 * document, so these are noise at best — and `.github` is worse than noise: the workflows build the
 * CLI's own source, so a brand-new adopter's first push turns their repo red.
 *
 * Pruned in the adopter's clone, never in the framework repo, which keeps whatever shape it needs.
 * `publish/` is deliberately NOT here: it is the copy source the framework replaces on upgrade.
 */
export declare const PUBLISHER_ONLY_DIRS: readonly string[];
/**
 * The framework's OWN working copies, which the template copy also brings.
 *
 * These are not the adopter's content. `publish/content/{agent,knowledge}` is the seed — 26 knowledge
 * files against the framework's own 4 — and per the publish-folder model the CLI GENERATES adopter
 * content from `publish/`, never inherits the framework's working directories. Pruned before seeding,
 * so the seed lands on a clean tree.
 */
export declare const INHERITED_DIRS: readonly string[];
/**
 * The framework's OWN root FILES, which the template copy also brings — and which used to
 * survive the seed and govern the adopter's agents.
 *
 * THE GOVERNANCE HOLE THIS CLOSES, found on a walk 2026-09-12. This repo has its own
 * `AGENTS.md`: twenty-five lines about contributing to the framework, which even says "the
 * adopter-facing agent protocol lives in `publish/content/`". `gh repo create --template`
 * copies it into every adopter's repo. Then the seed plans it as `scaffold-prompt`, and on a
 * FIRST seed there is no baseline to compare against — so `base === null`, the entry is
 * classified `conflict`, and `applyUpgrade` skips conflicts. The verdict "org-customized —
 * review before applying" was wrong: the adopter had customized nothing, they had inherited the
 * template.
 *
 * The consequence was invisible and total for two of the launch-list agents. `ensureRootProtocol`
 * mirrors `<workspace>/AGENTS.md` to the project root, so openai-codex and ibm-bob — both of
 * which read AGENTS.md — were handed instructions for building this repository instead of the
 * governance protocol. Nothing failed; they were simply governed by the wrong document.
 * `verifyAgentContext` is what finally noticed, because the file carries no renderer banner.
 *
 * `README.md` is the same mistake with a smaller blast radius: adopters were reading the
 * framework's README rather than the one written for them.
 *
 * Pruned in the adopter's clone, never in the framework repo. The framework keeps its own
 * AGENTS.md at the conventional name, which is right for its own contributors — it just must
 * not be inherited, exactly like `agent/` and `knowledge/` are not.
 */
export declare const INHERITED_FILES: readonly string[];
/**
 * What an adopter should be left with — asserted after pruning so a new publisher
 * dir cannot creep in. The FLOOR, not the whole answer: everything MANIFEST.yaml
 * scaffolds is expected too, and {@link expectedDirs} unions the two.
 */
export declare const ADOPTER_DIRS: readonly string[];
/**
 * Every top-level directory the manifest scaffolds into an adopter's repo (#193).
 *
 * A clean adoption used to end by calling `.claude .clinerules .continue .cursor
 * .gemini .github .windsurf docs projects` "unexpected directories" and asking to
 * be told if they were publisher-only. They are not: MANIFEST.yaml scaffolds every
 * one of them on purpose — the agent harness is what the session-start protocol
 * runs on. `.github` was in the publisher-only list AND in the manifest, which is
 * the clearest sign the two had drifted.
 *
 * The hand-kept list was a second description of something the manifest already
 * states file by file, and the manifest is the one the installer follows. Deriving
 * removes the copy rather than correcting it — the same move as retiring
 * `registry.yaml` in favour of GitHub, and `ADOPTER_DIRS` vs `~/.gov/<slug>` before it.
 */
export declare function expectedDirs(manifestText: string | null): readonly string[];
/**
 * Tokens that are SUPPOSED to survive setup: they belong to a project, and at setup
 * time there is no project. `gov seed` resolves them.
 *
 * Reporting these alongside real leaks is what made the warning easy to dismiss —
 * six of the eight it named were genuine, and these two were not.
 */
export declare const PER_PROJECT_TOKENS: ReadonlySet<string>;
/**
 * Token values from org-config.yaml's TEXT, not from its typed parse (#193).
 *
 * The sweep built its map from `parseOrgConfig`, whose interface carries the keys
 * gov-work itself reads — org name, slug, branches. It has no
 * `policy_owner_github`, no `legal_owner_github`, no `policy_effective_date`, so
 * those tokens had no values and survived into the adopter's policy documents:
 * exactly the first impression this whole flow exists to fix.
 *
 * The file is the authority on what it contains. Read it as such.
 */
export declare function tokenValuesFromOrgConfig(text: string): Record<string, string>;
/** One line per thing setup actually did, printed at the end instead of leaving it silent (6b/6d). */
export interface ManifestLine {
    readonly what: string;
    readonly detail: string;
}
export declare function renderManifest(lines: readonly ManifestLine[], nextSteps: readonly string[]): readonly string[];
/** Tokens resolved into adopter content at seed time, from org-config values. */
export declare function substituteTokens(text: string, values: Readonly<Record<string, string>>): string;
/** `<TOKEN>` occurrences left after substitution — a doc the adopter should never have to decode. */
export declare function leftoverTokens(text: string): readonly string[];
/**
 * Is an already-existing remote safe to adopt after a failed run (#159 finding 2)?
 *
 * `gh` cannot delete a repo without `delete_repo`, so a failed run leaves one behind and the retry hits
 * `Name already exists on this account`. Adopting blindly would prune and force-push over whatever is
 * there — unrecoverable if it is someone's real work. So: adopt ONLY what could only have come from a
 * failed run of this command, refuse anything else, and never guess between the two.
 */
export type AdoptVerdict = {
    readonly adopt: true;
    readonly why: "empty" | "template-shaped";
} | {
    readonly adopt: false;
    readonly why: "not-ours" | "cannot-tell";
    readonly detail: string;
};
export declare function canAdoptExisting(io: CreateIo, target: CreateTarget): AdoptVerdict;
/** Where a previous attempt's clone is moved so a retry can proceed without destroying evidence. */
export declare function archivePathFor(home: string, slug: string, stamp: string): string;
