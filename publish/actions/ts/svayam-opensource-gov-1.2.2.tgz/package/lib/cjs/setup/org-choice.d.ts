/**
 * "Which GitHub organization?" — asked with the answer already on screen where possible.
 *
 * Both interviews ask this: the adopter at Q3, the joiner at Q1. GitHub knows the answer —
 * `gh api user/orgs` lists the organizations the signed-in account belongs to — so asking
 * someone to recall and retype an identifier that is one API call away is a question gov does
 * not need to ask blind.
 *
 * THE LIST IS A CONVENIENCE, NEVER A GATE. `user/orgs` needs the `read:org` scope and returns
 * only what the token can see; an organization can be real, correct, and absent from it. So a
 * name that is not on the list is accepted exactly as before, and an empty list changes nothing
 * about what can be answered. This is the #197 discipline applied to a different probe: an
 * unverified answer says nothing and refuses nothing.
 */
/** Lines offering what GitHub knows, or none at all when it knows nothing. */
export declare function renderOrgChoices(orgs: readonly string[]): readonly string[];
/**
 * Turn an answer into an organization name.
 *
 * A bare number picks from the list; anything else is taken literally, trimmed. A number
 * OUTSIDE the list is returned untouched rather than rejected — an organization may legitimately
 * be called `42`, and inventing a refusal for a name gov cannot see is how the probe would stop
 * being a convenience and start being a gate.
 */
export declare function resolveOrgChoice(answer: string, orgs: readonly string[]): string;
/**
 * The default to offer.
 *
 * Only when there is exactly ONE organization: a default is a suggestion that Enter accepts, and
 * suggesting the first of several is not a suggestion, it is a coin toss with consequences —
 * the adopter's answer decides where a repository gets created.
 */
export declare function defaultOrg(orgs: readonly string[], fallback: string): string;
