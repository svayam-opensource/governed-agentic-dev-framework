import type { ApprovedAgent } from "../config/approved-agents.js";
/** Thrown when a prompt cannot get a usable answer — never on a human's typo. */
export declare class JoinRefused extends Error {
}
export interface JoinInterviewIo {
    readonly prompt: (question: string, def: string) => Promise<string>;
    readonly print: (line: string) => void;
    /** Organizations the signed-in GitHub account belongs to. Empty when gov cannot tell. */
    readonly myOrgs?: () => readonly string[];
    /**
     * Governance repositories inside `org`, as `owner/repo`. Runs the instant Q1 is answered.
     * Returns null when the probe could not run — which must read as "gov does not know", never
     * as "there are none".
     */
    readonly governanceReposIn?: (org: string) => readonly string[] | null;
    /**
     * The agents this organization has AUTHORIZED, read from the governance repo before it is
     * cloned. null when gov cannot tell — which includes the common case of an organization
     * whose policy predates the approved-agents list and simply has none.
     */
    readonly approvedAgentsIn?: (org: string, repo: string) => readonly ApprovedAgent[] | null;
}
export interface JoinInterviewResult {
    readonly org: string;
    /** Repository name only, not `owner/repo`. */
    readonly repo: string;
    /**
     * The authorized agent this joiner picked (Q3), or undefined when the question was not
     * asked — the organization recorded no list, so there is nothing to pick from and gov must
     * not invent one.
     */
    readonly agent?: string;
}
/**
 * The opening block. Says what joining DOES before asking for anything, because the joiner's
 * first fear is that they are about to create something in their organization — and they are
 * not; this path only clones.
 */
export declare const JOIN_HEADER: readonly string[];
export interface JoinOutcome {
    readonly repoUrl: string;
    readonly localPath: string;
    readonly projectsPath: string;
}
/**
 * The closing block. "Cloned to", never "created": the repository already existed, and telling a
 * joiner they created it is the one sentence that could make them think they had done something
 * to their organization.
 */
export declare function joinSummary(o: JoinOutcome): readonly string[];
/**
 * Two questions. Returns null when the joiner pressed Enter at the first with nothing to accept,
 * which is the clean stop the old clone-URL prompt also offered.
 */
export declare function askJoinInterview(io: JoinInterviewIo): Promise<JoinInterviewResult | null>;
/** For the caller: what to clone, given the two answers. */
export declare function cloneTargetFor(r: JoinInterviewResult): {
    readonly nameWithOwner: string;
    readonly url: string;
};
