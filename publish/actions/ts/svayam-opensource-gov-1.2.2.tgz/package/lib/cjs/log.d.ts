/** The code path convention: `<package>:<dir>:<module>` — see the logger's README. */
export declare const APP_ID = "gov-work";
/**
 * Where this run's log belongs.
 *
 * PURE, and separate from everything that writes, because the branch that matters — "is there
 * an organization yet?" — is the one worth testing, and testing it should not require a disk.
 */
export declare function logDirFor(activeOrg: string | null, home?: string, platform?: NodeJS.Platform): string;
/**
 * Record one decision.
 *
 * `pgm` is the CODE PATH — `gov-work:cli:ask` is `src/cli/ask.ts` — so a reader can get from a
 * line to the file without guessing, and can switch that one module on by name:
 *
 *     NODE_DEBUG=gov-work:cli:ask gov work
 *
 * Never throws. A logging failure must not become the user's problem.
 */
export declare function log(level: "error" | "warn" | "info" | "debug", msg: string, pgm: string, fn: string, meta?: unknown): void;
/** Flush before a short-lived process exits, or the last lines — the interesting ones — are lost. */
export declare function closeLog(): void;
