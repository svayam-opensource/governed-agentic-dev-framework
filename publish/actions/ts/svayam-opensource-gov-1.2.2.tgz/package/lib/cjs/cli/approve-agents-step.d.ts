import type { ApprovedAgent } from "../config/approved-agents.js";
/** The agents worth offering at adoption: the ones with something to run. */
export declare function selectableAgents(): readonly {
    readonly id: string;
    readonly tool: string;
    readonly how: string;
}[];
export declare function approvalPrompt(color?: boolean): readonly string[];
export type ApprovalChoice = {
    readonly ok: true;
    readonly agents: readonly ApprovedAgent[];
} | {
    readonly ok: false;
    readonly message: string;
};
/**
 * Read the answer. Refuses an empty one: this is the single question that must be
 * answered, because everything downstream — installs, the joiner's flow, the work
 * menu — reads the list it produces.
 */
export declare function parseApprovalChoice(answer: string): ApprovalChoice;
/** What was recorded, said plainly, because it is a rule now. */
export declare function approvalSummary(agents: readonly ApprovedAgent[]): readonly string[];
