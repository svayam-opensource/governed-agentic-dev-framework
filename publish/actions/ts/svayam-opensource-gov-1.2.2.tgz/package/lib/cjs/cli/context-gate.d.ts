/** Show the banner (always) and prompt only on a CHANGED context fingerprint. Returns false to bail. */
export declare function confirmContextOrBail(argv: readonly string[]): Promise<boolean>;
