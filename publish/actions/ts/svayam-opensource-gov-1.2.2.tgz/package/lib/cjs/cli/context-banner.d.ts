export type ContextMode = "project" | "governed" | "none";
export interface ContextInfo {
    readonly mode: ContextMode;
    readonly projectPath?: string;
    /** The org's agent_work_root (org-config) — the parent of both project dirs and `.bases`. NOT in the
     *  fingerprint (derived from org-config, which already fingerprints via orgConfigHash). */
    readonly agentWorkRoot?: string;
    readonly govRepo?: string;
    readonly orgConfigPath?: string;
    readonly orgConfigHash?: string;
    readonly user?: string;
    readonly branch?: string;
    readonly services: Readonly<Record<string, string | undefined>>;
    readonly anomalies: readonly string[];
}
/** The FINGERPRINT — the discriminating facts that define "am I in the right place with the right settings".
 *  A change in ANY of these re-prompts: mode · project · gov_repo · org-config PATH · org-config CONTENT ·
 *  user · target env · CLI MAJOR (a major upgrade re-confirms once). */
export declare function contextFingerprint(info: ContextInfo, targetEnv?: string, cliVersion?: string): string;
export declare function hashText(text: string): string;
/** The human banner (always shown). Never prints a secret value — URLs/presence only. */
export declare function renderBanner(info: ContextInfo, targetEnv?: string): string[];
export interface Ack {
    fp: string;
    at: number;
}
export declare function isAcked(records: readonly Ack[], fp: string, now: number): boolean;
export declare function recordAck(records: readonly Ack[], fp: string, now: number): Ack[];
