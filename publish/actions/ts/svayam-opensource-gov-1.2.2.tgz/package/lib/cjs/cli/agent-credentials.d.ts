/** A short, stable fingerprint. Enough to compare, useless to steal. */
export declare function fingerprint(secret: string): string;
/** Do two copies of a key match? Neither is returned, logged, or shown. */
export declare function keysAgree(a: string | null, b: string | null): boolean;
export interface CredentialWrite {
    readonly path: string;
    readonly contents: string;
    readonly mode: number;
}
/**
 * The two writes, planned. `0600` on the file and `0700` on its directory: a key
 * readable by every process on a shared machine is a key that has already leaked.
 */
export declare function planCredentialWrites(agentId: string, key: string, agentConfigPath: string, preferencesDir: string): readonly CredentialWrite[];
/** What to say while doing it, since a key is being handled and that deserves saying. */
export declare function credentialNotice(agentId: string, agentConfigPath: string, preferencesDir: string): readonly string[];
