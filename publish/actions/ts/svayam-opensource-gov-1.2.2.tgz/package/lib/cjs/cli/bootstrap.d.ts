/**
 * FIRST RUN — from a bare machine to a registered org, in one command (PRJ-43 walkthrough, 2026-08-07).
 *
 * `gov` on a machine with no `org_registry` used to print *"no gov workspace resolved — run `gov setup` /
 * `gov org use`"*: two verbs taught at the moment of failure, and the work handed back. It now asks the one
 * question it actually needs — which governance repo? — and does the rest.
 *
 * ## The order, and why it is that order
 *
 * `gov_home` lives at `~/.gov/<org_slug>/gov_repo`, and **`org_slug` is inside the repo being cloned**. So the
 * destination cannot be computed before the clone exists. Cloning to a temp location and then placing it is
 * not a workaround: the alternative is deriving a slug from the URL and letting `org-config.yaml` disagree
 * with the path it lives at — a second copy of a value, with nothing comparing them, which is the shape
 * behind most of this project's defects.
 *
 * ## Joining versus founding
 *
 * After the clone, exactly one question decides everything: **does it already have `org-config.yaml`?**
 *
 *   yes → JOINING. ~Everyone. The org's identity exists; a newcomer must never be prompted to author it,
 *         because those answers are committed to a repo the whole org reads.
 *   no  → FOUNDING. Once, by one person. This is what `setup` is, and the only path that reaches it.
 *
 * That conditional is why `setup` needs no refuse-on-exists guard: the flow never reaches it for a repo that
 * is already configured.
 *
 * ## With no terminal
 *
 * Print and exit. First run is a human act, once per machine (Policy Owner, 2026-08-07). The accepted
 * consequence is that a fresh CI runner cannot onboard itself; everything downstream IS non-interactive, so
 * if that ever bites, the fix is one flag rather than a redesign.
 */
import { type SetupPreAnswers } from "../setup/interview.js";
import type { OrgConfigValues } from "../setup/setup.js";
/** What the bootstrap must do next. Pure data — the caller performs it. */
export type BootstrapStep = 
/** nothing to do: an org is registered and active. */
{
    readonly kind: "ready";
    readonly org: string;
}
/** registered orgs exist but none is active — pick one (or `--org`). */
 | {
    readonly kind: "choose";
    readonly orgs: readonly string[];
}
/** nothing registered: ask for the governance repo and clone it. */
 | {
    readonly kind: "clone";
}
/** no terminal, and something needs asking. */
 | {
    readonly kind: "blocked";
    readonly reason: string;
};
export interface RegistryFacts {
    /** orgs already registered on this machine. */
    readonly orgs: readonly string[];
    /** the active org, if one is selected. */
    readonly active: string | null;
    /** is there a terminal to ask in? */
    readonly interactive: boolean;
}
/**
 * The rung the machine is on. Deliberately does NOT look at the filesystem or the network — the caller
 * supplies what it knows, so every branch is decidable in a test.
 */
export declare function nextStep(f: RegistryFacts): BootstrapStep;
/**
 * Where a freshly cloned governance repo belongs: `~/.gov/<org_slug>/gov_repo`.
 *
 * Under `~/.gov/`, not `~/.<slug>/` (#186). Three parts of this tool had three
 * answers: `create.ts` placed a NEW workspace at `~/.gov/<slug>/gov_repo`, the
 * registry that maps orgs to homes lives at `~/.gov/workspaces`, and this — the
 * JOINING path — put the clone at `~/.<slug>/gov_repo`. So founding and joining
 * the same organization on the same machine produced two different layouts.
 *
 * `~/.gov/` as the root is also what makes more than one governed organization
 * workable: every org is a sibling directory next to the registry that enumerates
 * them, instead of being scattered across the home directory with nothing to list.
 *
 * The slug is read from the clone's own `org-config.yaml`, so a JOINER lands exactly where the org says,
 * not where a URL suggested. A FOUNDER has no config yet, so the caller passes the slug the setup questions
 * produced — same rule, later input.
 *
 * Lower-cased, because the slug is authored uppercase (`SVM`) while the directory is not (`~/.svm`) — the
 * same pairing `org_slug` / `org_slug_lower` already makes inside org-config.yaml.
 */
export declare function govHomeFor(homeDir: string, orgSlug: string, join?: (...p: string[]) => string): string;
/** `git@github.com:Svayamtech/svm-prj-work.git` / `https://github.com/Svayamtech/svm-prj-work` → `svm-prj-work`. */
export declare function repoNameFromUrl(url: string): string | null;
/** Is this a plausible clone URL? A typo'd answer should fail HERE, not inside git's output. */
export declare function looksLikeRepoUrl(s: string): boolean;
/**
 * A clone URL for a repo gov found itself, shown as the default the user can override (#197).
 *
 * https rather than ssh because it is the one that works on a machine that has only done what the
 * checklist asked — `gh auth login`, no key generated, no key uploaded. It is a DEFAULT, not a
 * decision: someone whose org requires ssh edits the line. The clone itself prefers `cloneRepo`
 * (`gh repo clone`), which resolves protocol and credentials the way `gov setup` already does.
 */
export declare function cloneUrlFor(nameWithOwner: string): string;
/** What gov knows about an organization's existing governance repos (#197). */
export interface GovernanceProbe {
    /** `owner/repo` for every repo in the org that declares an `org-config.yaml`. */
    readonly repos: readonly string[];
    /** false = the probe could not run. Say NOTHING then — a guess here is a forked policy. */
    readonly verified: boolean;
}
/**
 * What the first run asks before anything else (#186).
 *
 * The prompt used to ask for a governance repo clone URL. Only a JOINER can answer
 * that: an adopter's governance repo does not exist yet — `gov setup <org>/<repo>`
 * is what creates it. So the first question was answerable by roughly half the
 * people who reached it, and the other half went looking for a repository that was
 * never going to be found.
 *
 * Asking the ROLE first is not an extra step; it is the step that decides which
 * question is worth asking. And because "which am I?" is a fair thing not to know,
 * C is a real answer rather than a way of saying no.
 */
export type FirstRunRole = "adopter" | "joiner" | "explain";
/** The two roles adoption can END in. "explain" is a request for help, not a destination. */
export type AdoptionRole = "adopter" | "joiner";
export declare function parseRole(answer: string): FirstRunRole | null;
/**
 * The question, coloured or not (#204). A LETTER IS THE ANSWER, so the letters are what the
 * eye has to find — bold makes them findable and the layout still works without it. The
 * explanation of each option stays plain: it is what you read, not what you pick.
 */
export declare function roleQuestion(color?: boolean): readonly string[];
/** The plain form, kept because tests and any non-terminal caller want exactly this. */
export declare const ROLE_QUESTION: readonly string[];
/**
 * Shown for C, and again after any unrecognised answer. Deliberately explains
 * GitHub organizations too: the framework is adopted per ORGANIZATION, and a
 * newcomer who thinks their personal account is their organization will adopt into
 * the wrong place — a mistake nothing downstream can detect.
 */
export declare const ROLE_EXPLANATION: readonly string[];
/**
 * What someone is told when they answered ADOPTER for an organization that is already governed (#197).
 *
 * This is not a refusal, and must not read like one. They answered the role question truthfully with
 * what they knew; gov then went and looked, and found out otherwise. The only thing that has changed
 * is which of the two paths they are on — so the screen says that, names the repository, and offers
 * the path they are actually on. Being told "no" and handed a shell command was the old behaviour, and
 * the command it handed them could not produce a working machine.
 */
export declare function alreadyGovernedNotice(org: string, repos: readonly string[], color?: boolean): readonly string[];
/** The org identity a governance repo declares about itself. */
export interface OrgIdentity {
    readonly org: string;
    readonly orgSlug: string;
}
/**
 * Everything the first run touches that is not a decision: the network, the disk, the registry, the
 * terminal. Injected so the whole flow below is decidable in a test — no clone, no home directory.
 */
export interface FirstRunIo {
    readonly facts: RegistryFacts;
    /**
     * May this run's output carry ANSI (#204)? Decided by the CALLER, because these lines go to
     * STDERR — which is a different stream from the one every other screen is gated on, and can
     * be redirected on its own.
     */
    readonly color?: boolean;
    /** the user's home directory — `gov_home` is derived from it, never from cwd. */
    readonly homeDir: string;
    prompt(question: string, def: string): Promise<string>;
    /** progress + errors. stdout stays free for whatever the real command prints. */
    print(line: string): void;
    /** a fresh empty directory to clone into. */
    tempDir(): string;
    /** clone `url` into `dest`; throw with git's own message when it fails. */
    clone(url: string, dest: string): void;
    /**
     * Clone `owner/repo` with `gh`, which resolves the protocol and the credentials — the same
     * mechanism `gov setup` uses for the repo it creates. Used only for a repo GOV found, never for a
     * URL the user typed. Optional: without it the derived https URL goes through `clone`.
     */
    cloneRepo?(nameWithOwner: string, dest: string): void;
    /**
     * Does this GitHub organization already have a governance repo (#197)?
     *
     * Asked BEFORE the questions only an adopter can answer, because the answer decides whether those
     * questions are worth asking. Optional: absent means "do not probe", and the flow is as it was —
     * `preflight` still refuses to create a second one either way.
     */
    probeGovernance?(org: string): GovernanceProbe;
    /**
     * Organizations the signed-in GitHub account belongs to, offered as a numbered list at the
     * one question both interviews ask.
     *
     * A CONVENIENCE, NEVER A GATE. It needs the `read:org` scope and returns only what the token
     * can see, so an organization can be real, correct, and absent. Absent means "gov cannot
     * help here", never "that is not your organization" — the #197 discipline, applied to a
     * different probe.
     */
    listMyOrgs?(): readonly string[];
    /**
     * The agents an organization has authorized, read from its governance repo BEFORE the clone,
     * so the joiner's Q3 can sit with the other questions. null when gov cannot tell — including
     * an organization whose policy simply has no list, where offering the framework's own
     * catalogue would present gov's defaults as the org's policy.
     */
    approvedAgentsIn?(org: string, repo: string): readonly {
        readonly id: string;
        readonly default?: boolean;
    }[] | null;
    /** the repo's declared identity, or null when it has none yet (→ FOUNDING). */
    readIdentity(repoDir: string): OrgIdentity | null;
    /** does anything already live here? Placing must never overwrite an existing home. */
    exists(dir: string): boolean;
    /** move the clone to its final home. */
    place(from: string, to: string): void;
    /** best-effort cleanup of a temp clone. */
    discard(dir: string): void;
    /** author `org-config.yaml` in a repo that has none — the FOUNDING path (`gov setup`). */
    found(repoDir: string): Promise<OrgIdentity | null>;
    /**
     * The ADOPTER path: create the organization's governance repo from the template
     * and configure it — i.e. `gov setup <org>/<repo>`. Returns its exit code.
     *
     * `pre` carries the answers the interview already collected, so nothing downstream
     * asks again. Every question now precedes creation (see setup/interview.ts), and a
     * second prompt for a settled fact is how the slug came to have two answers (#159
     * finding 1a).
     */
    createWorkspace(target: string, pre?: SetupPreAnswers): Promise<number>;
    /**
     * Defaults for the org interview, derived from the environment (gh user, git email,
     * today). Injected because only the caller knows those facts. Absent means the
     * interview offers no defaults, which is usable but joyless.
     */
    deriveOrgDefaults?: (partial: Partial<OrgConfigValues>) => OrgConfigValues;
    /** Record the org's approved agents in llm-governance.md. Returns whether it wrote (#196). */
    approveAgents?: (agents: readonly {
        readonly id: string;
        readonly default?: boolean;
    }[]) => boolean;
    /** Build the starter review project; returns the lines to print (#186). */
    createStarterProject?: () => readonly string[];
    /**
     * The whole checklist, ticked, at the true end of the run (#186).
     *
     * The role is PASSED, not assumed. It used to be hardcoded to "adopter", so a joiner who finished
     * cleanly was shown the founding steps against their own name — a list of things they must not do
     * (#197). Step 8 is the one item that differs, and the caller is the only one who knows which
     * branch was actually walked.
     */
    finalStatus?: (role: AdoptionRole) => readonly string[];
    /** What to do now, for an adopter. */
    adopterNextSteps?: () => readonly string[];
    /**
     * Start the work the next-steps block just described (#203).
     *
     * BOTH ROLES END WITH THREE STEPS TO RETYPE, so both get the offer. An adopter is sent to
     * the starter review project by name; a joiner has no such project — theirs is whichever
     * they are assigned — so they get the picker, which is step 3 of their own instructions.
     *
     * Returns the exit code of that session, or null when there was nothing to open — no
     * starter project, or no workspace resolved. Optional: without it the run ends exactly
     * as it did.
     */
    /**
     * Offer the work flow now (#203). `agent` is the authorized agent a JOINER picked at Q3 —
     * passed so the flow does not re-ask a question the interview already answered.
     */
    reviewNow?: (role: AdoptionRole, agent?: string) => Promise<number | null>;
    /** What to do now, for a joiner. */
    joinerNextSteps?: () => readonly string[];
    /** register the home and make it active. */
    register(org: string, home: string): {
        readonly ok: boolean;
        readonly message?: string;
    };
    /** select an already-registered org. */
    activate(org: string): {
        readonly ok: boolean;
        readonly message?: string;
    };
}
/**
 * Run the first-run flow. Returns null when there was nothing to do — the caller then proceeds with the
 * command the user actually typed. Any number is an exit code.
 *
 * Returning `null` rather than `0` matters: "already set up" and "just finished setting up" must not look
 * alike to the caller, or the command the user typed would be swallowed by its own prerequisite.
 */
export declare function runFirstRun(io: FirstRunIo): Promise<number | null>;
