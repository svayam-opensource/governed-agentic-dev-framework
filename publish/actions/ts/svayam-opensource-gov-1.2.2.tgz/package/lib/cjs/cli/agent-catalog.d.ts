/**
 * Which agents gov may offer, and what it knows about each (#195).
 *
 * The menu used to be four hard-coded lines — Claude, cursor, Cursor GUI, shell —
 * offered whole to a machine with none of them installed, and led by a tool the
 * policy the same install had just seeded lists as prohibited.
 *
 * WHAT MAKES AN AGENT OFFERABLE IS A HARNESS. `agent/harness-manifest.yaml` renders
 * a rules file per tool — CLAUDE.md, .cursor/rules/agent.mdc, .clinerules/agent.md
 * and the rest — and that file is how the session protocol reaches the agent at all.
 * A tool with no harness would be launched into a project it cannot read the rules
 * of, which is worse than not offering it. So the manifest is the list, and a test
 * holds this file to it rather than a second hand-kept copy drifting from the first
 * — the same fix as ADOPTER_DIRS against MANIFEST.yaml and the itinerary against
 * the checklist.
 *
 * HOW THE RULES ARRIVE differs, and the menu should say so:
 *
 *   cli   gov passes the protocol as an argument      claude "<protocol>"
 *   ide   gov opens the folder; the tool's own agent reads the rules from the repo
 *
 * Both are governed. "Run an agent" and "open my editor here" are still not the
 * same offer, and one undifferentiated row said they were.
 */
export type LaunchKind = "cli" | "ide" | "none";
/**
 * One way to run an approved agent (#196, Q8). The policy approves the AGENT — its
 * real question is which provider may see your code, and that does not change
 * between a CLI and an extension of the same tool — so a single approval brings all
 * of its variants.
 */
export interface AgentVariant {
    readonly kind: "cli" | "editor" | "extension";
    readonly label: string;
    /** The command to probe and to launch. Extensions have none of their own. */
    readonly cmd?: string;
    /** npm package, or a shell line for a vendor installer. */
    readonly install?: {
        readonly npm?: string;
        readonly script?: string;
        readonly pip?: string;
        readonly url: string;
    };
    /** For extensions: the marketplace id, installed through the host's own CLI. */
    readonly extensionId?: string;
    /** The hosts that can carry this extension, in preference order. */
    readonly hosts?: readonly string[];
    /** The agent's own login command, when it has one — tier 1 of the sign-in design. */
    readonly login?: readonly string[];
}
export interface AgentCandidate {
    /** Matches the harness manifest's `id`, which is what makes this list checkable. */
    readonly id: string;
    readonly tool: string;
    readonly launch: LaunchKind;
    /** The executable to probe and to run. Absent when gov cannot launch it. */
    readonly cmd?: string;
    /**
     * How to install it. `npm` is a named package from a named publisher; `script` is
     * a vendor's own installer, piped into a shell. gov runs either — but only for an
     * agent the org has approved, because approval IS the trust decision (#196, Q2).
     */
    readonly install?: {
        readonly npm?: string;
        readonly brew?: string;
        readonly script?: string;
        readonly pip?: string;
        readonly url: string;
    };
    /** The environment variable that would hold a key, so gov can report its absence. */
    readonly credentialEnv?: string;
    /**
     * Known to gov, NOT yet offered at adoption (Policy Owner, 2026-09-10).
     *
     * A launch list of ten is ten paths a real adopter can take, of which two have verified
     * prompt delivery. The decision was to make a smaller list foolproof first and expand from
     * there — so these entries keep their catalog knowledge, their manifest parity and their
     * tests, and simply do not appear in the Q10 menu.
     *
     * DEFERRAL AFFECTS THE MENU ONLY. An organization that already approved one of these keeps
     * working: `approvedAgents` still resolves it, `agentLaunchSpec` still launches it. Upgrading
     * gov must never take an agent away from an org that is using it.
     */
    readonly deferred?: true;
    /**
     * It opens its own browser the first time it needs to authenticate (#208).
     *
     * The THIRD sign-in shape, and the one the code did not have. gov had two — a `login`
     * subcommand to run, or an API key to ask for — so "no login command" was read as "needs a
     * key", and an adopter was asked for a BOB_API_KEY by a tool that then opened a browser on
     * its own. `credentialEnv` may still be set alongside this: a key is how the agent runs
     * HEADLESS, where no browser can be opened. It means a key CAN be used, never that gov
     * should ask for one.
     */
    readonly signsInItself?: true;
    /** Where a tier-2 key belongs — the agent's own config, never gov's. */
    readonly credentialFile?: string;
    /**
     * How this agent takes the session-start prompt, with `{prompt}` substituted (#207).
     *
     * ABSENT MEANS GOV DOES NOT KNOW, and it does not guess. Every `cli` agent used to be
     * handed the prompt as a bare positional, which is right for the two that were checked
     * and wrong for `bob`, which takes none: "too many arguments. Expected 0 arguments but
     * got 1." — after a clean install and a "Starting it in…".
     *
     * Where it is absent the agent is launched bare and the prompt is printed to paste. The
     * harness file this catalog exists to guarantee — AGENTS.md, CLAUDE.md, the cursor rule —
     * is what actually governs the session; the prompt only makes the agent speak first.
     * Filling these in means running each vendor's CLI and recording what it accepts.
     */
    readonly promptArgv?: readonly string[];
    /** Where to go to create an account, when there is no automating it. */
    readonly signupUrl?: string;
    /** Every way to run it. The policy approves the agent; this is what that buys. */
    readonly variants?: readonly AgentVariant[];
}
/**
 * Every harness the framework renders. `launch: "none"` entries are governed but
 * not startable from here — a browser tool has no command to run.
 */
export declare const AGENT_CATALOG: readonly AgentCandidate[];
/** The Cursor editor, which is a launch target rather than its own harness. */
export declare const CURSOR_GUI: AgentCandidate;
export interface AgentStatus {
    readonly candidate: AgentCandidate;
    readonly installed: boolean;
    /** Null when gov cannot tell — which is not the same as "no". */
    readonly credentialPresent: boolean | null;
}
/**
 * What is actually on this machine. `hasTool` and `env` are injected, so the whole
 * decision is decidable without a shell.
 */
export declare function agentStatuses(candidates: readonly AgentCandidate[], hasTool: (cmd: string) => boolean, env: Readonly<Record<string, string | undefined>>): readonly AgentStatus[];
/**
 * The approved set. An org that has not decided yet gets the framework's own list,
 * and is told so — an empty menu on day one would make the feature useless exactly
 * when it is needed most.
 */
export declare function approvedAgents(orgApproved: readonly string[] | null): {
    readonly ids: readonly string[];
    readonly usingDefaults: boolean;
};
/**
 * The instructions file this agent reads, relative to the project root — or null when gov has
 * no way to govern its session except by handing it a first message.
 *
 * WHY THIS MATTERS MORE THAN A PROMPT. No CLI agent speaks first; every one of them waits for
 * input. gov once leaned on a Claude-only SessionStart hook to close that gap, and the hook was
 * removed (2026-09-11) — not because it failed, but because a mechanism one vendor has makes
 * that vendor the better-governed choice for a reason unrelated to the agent, and it biases the
 * selection at Q10.
 *
 * It cost nothing to remove, because an instructions file read on EVERY TURN was always the
 * stronger half: it governs the whole session rather than its opening. So when this returns a
 * path, gov's job is done by `ensureRootProtocol` mirroring the file and `verifyAgentContext`
 * refusing to launch if it did not land — and the honest instruction to the human is "say
 * anything", not "paste these five lines".
 *
 * Kept beside the catalog and matching `agent/harness-manifest.yaml`, which is what renders
 * them. An agent absent from both is ungoverned, and gov says so rather than implying otherwise.
 */
export declare function harnessFileFor(agentId: string): string | null;
/** Offerable = approved, launchable, and actually here. */
export declare function offerable(statuses: readonly AgentStatus[], approvedIds: readonly string[]): readonly AgentStatus[];
/** Approved, launchable, and missing — the ones worth offering to install. */
export declare function installable(statuses: readonly AgentStatus[], approvedIds: readonly string[]): readonly AgentStatus[];
/** One line each, saying what it is rather than only what it is called. */
export declare function menuLines(offer: readonly AgentStatus[]): readonly string[];
/** Shown when nothing is installed: what could be, and how. */
export declare function nothingInstalledLines(missing: readonly AgentStatus[], usingDefaults: boolean): readonly string[];
/**
 * The agent ids an org has approved, read from its own `llm-governance.md`.
 *
 * Deliberately forgiving: the file is prose with a table in it, maintained by a
 * human, and a parse failure must not empty the menu. Null means "could not tell",
 * which falls back to the framework's list and says so — never to nothing.
 */
export declare function approvedAgentIdsFrom(policyText: string | null): readonly string[] | null;
/** Which variants of an agent can run on this machine right now (#196, Q7). */
export interface VariantStatus {
    readonly agent: AgentCandidate;
    readonly variant: AgentVariant;
    readonly installed: boolean;
    /** For an extension: the host it would attach to, or null when none is present. */
    readonly host: string | null;
}
/**
 * Enumerate an approved agent's variants against this machine.
 *
 * An extension with no host is NOT offered, and gov does not install the host to
 * create one: putting a desktop IDE on someone's machine is a provisioning decision,
 * not an agent one — irreversible by `npm rm -g`, meaningless headless, and usually
 * IT's call. Nobody is stranded by that, because an approved agent almost always has
 * a CLI variant too (#196, Q7).
 */
export declare function variantStatuses(agent: AgentCandidate, hasTool: (cmd: string) => boolean): readonly VariantStatus[];
/** Runnable now: a CLI or editor that is installed, or an extension with a host. */
export declare function runnableVariants(all: readonly VariantStatus[]): readonly VariantStatus[];
