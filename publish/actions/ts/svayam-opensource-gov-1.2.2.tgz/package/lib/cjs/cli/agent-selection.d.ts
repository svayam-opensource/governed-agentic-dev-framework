import type { ApprovedAgent } from "../config/approved-agents.js";
/** One row of the menu. `n` is the STABLE catalog position, not a position in this list. */
export interface OfferedAgent {
    readonly n: number;
    readonly id: string;
    readonly tool: string;
    readonly how: string;
}
/** Every agent with something to run, numbered once, minus anything already chosen. */
export declare function offeredAgents(exclude?: readonly string[]): readonly OfferedAgent[];
/** `Choose [1/2/4/…]` — the numbers still on offer, in catalog order. */
export declare function optionsLabel(offered: readonly OfferedAgent[]): string;
/**
 * The first question: which agent is the organization's DEFAULT.
 *
 * Asked first and alone because it is the answer that governs everyone who joins — and in the
 * old shape it was implied by typing order, which is not a way to state a policy.
 */
export declare function defaultAgentLines(offered: readonly OfferedAgent[], color?: boolean): readonly string[];
/** Every question after the first: one more agent, or nothing and we are done. */
export declare function addMoreLines(offered: readonly OfferedAgent[], color?: boolean): readonly string[];
/** `'IBM Bob' (default), 'OpenAI Codex' and 'Claude Code'` — Oxford-free, as an operator would say it. */
export declare function namesSentence(agents: readonly ApprovedAgent[]): string;
/** Read it back before it becomes a rule. */
export declare function confirmLines(agents: readonly ApprovedAgent[]): readonly string[];
export type PickResult = {
    readonly kind: "pick";
    readonly id: string;
} | {
    readonly kind: "done";
} | {
    readonly kind: "error";
    readonly message: string;
};
/**
 * One answer, against what is currently on offer.
 *
 * `allowDone` is false for the default question — an organization with no approved agent
 * cannot run any, so that one answer is not optional. It is true for every addition.
 */
export declare function parsePick(answer: string, offered: readonly OfferedAgent[], allowDone: boolean): PickResult;
export interface SelectIo {
    /** Ask, with the label already built by the caller; returns the raw answer. */
    readonly prompt: (question: string, def: string) => Promise<string>;
    readonly print: (line: string) => void;
    readonly color?: boolean;
}
/**
 * Drive the whole selection. Returns null when no usable answer arrives — bounded, because
 * "ask again" assumes someone is there to answer, and a scripted stdin repeats itself forever.
 */
export declare function askAgentSelection(io: SelectIo): Promise<readonly ApprovedAgent[] | null>;
