/**
 * Which agent to launch, and who decided (#196, Q9).
 *
 * Three layers already existed; the mistake would be inventing a fourth memory.
 *
 *   org      llm-governance.md    what is ALLOWED, and the default when >1
 *   user     preferences/<gh>.md  what this person LIKES, C03
 *   here     the prompt           only when neither layer answers
 *
 * The ordering is the honest one: an organization decides what may be used, a person
 * decides among those, and the question is asked once rather than daily.
 *
 * A PREFERENCE IS CHECKED AT LAUNCH, not at write time. If it were validated only
 * when written, an org narrowing its policy would keep launching the now-forbidden
 * tool until someone happened to edit their preferences — which is precisely the
 * shape of a rule that exists and does not bite. C03 already says a preference
 * cannot override org knowledge; this is what that means in code.
 */
import type { ApprovedAgent } from "../config/approved-agents.js";
export type ChoiceSource = "only-one" | "preference" | "org-default" | "asked" | "none";
export interface ChoiceResult {
    readonly id: string | null;
    readonly source: ChoiceSource;
    /** Set when a stated preference could not be honoured — always said out loud. */
    readonly ignoredPreference?: {
        readonly id: string;
        readonly why: string;
    };
}
/**
 * Decide without asking, if the layers allow. `runnableIds` is what is actually
 * installed: a preference for a tool that is approved but absent is not an error,
 * it just cannot be honoured today.
 */
export declare function chooseAgent(approved: readonly ApprovedAgent[] | null, preference: string | null, runnableIds: readonly string[]): ChoiceResult;
/** Say who decided, so nobody has to guess why a particular agent opened. */
export declare function choiceExplanation(r: ChoiceResult, toolName: (id: string) => string): readonly string[];
