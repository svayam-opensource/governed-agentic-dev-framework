/**
 * The whole adoption, on one screen, ticked off as it happens (#186).
 *
 * Adoption is a dozen steps across two processes — a shell installer that has no
 * Node yet, then `gov` itself — and an adopter met them one surprise at a time:
 * a prompt with no idea how many more were coming, an install that seemed finished
 * and then asked for something else, a browser sign-in arriving out of nowhere. The
 * complaint underneath every one of those was the same: *what is this going to do,
 * and how far along am I?*
 *
 * DERIVED, NOT RECORDED. There is no progress file, and there must not be: two
 * processes writing one would disagree, and a stale tick is worse than no tick.
 * Every item is a question gov can answer by looking — is Node here, is `gh` signed
 * in, does the workspace resolve — so the list is recomputed each time it is shown
 * and cannot drift from the machine it describes.
 *
 * The steps an installer owns (Node, gov itself) are ticked by the time gov can run
 * at all, which is why they are safe to derive too: if you are reading this list,
 * they are done.
 */
/** What gov can see about how far adoption has got. */
export interface ChecklistFacts {
    readonly gitPresent: boolean;
    readonly ghPresent: boolean;
    readonly ghAuthenticated: boolean;
    readonly ghScopesOk: boolean;
    readonly gitIdentityOk: boolean;
    readonly workspaceResolves: boolean;
    readonly orgActive: string | null;
    readonly workspacePath: string | null;
    readonly orgSlug: string | null;
    /** Adopter (founding) or joiner. Null before the question is answered. */
    readonly role: "adopter" | "joiner" | null;
    /** The ids in the org's approved_agents block, if it has one yet (#196). */
    readonly approvedAgents?: readonly string[];
    /**
     * Whether the starter project's review issue is closed — which is what "the
     * policies were reviewed" MEANS here, so even the soft step derives (#196, Q12).
     */
    readonly policiesReviewed?: boolean;
    /** The package manager, so the commands shown are the ones that will run. */
    readonly installCmd?: {
        readonly git: string;
        readonly ghRepo?: string;
        readonly gh: string;
    };
}
export interface ChecklistItem {
    readonly n: string;
    readonly done: boolean;
    readonly text: string;
    /** Indented under its parent. */
    readonly sub?: boolean;
}
/**
 * The list. Numbering matches what the adopter was shown a moment ago, so an item
 * does not change its number as the run progresses — a checklist whose lines move
 * is not a checklist.
 */
export declare function checklist(f: ChecklistFacts): readonly ChecklistItem[];
/**
 * `color` off by default (#204): the tick is the meaning, and the colour only makes it easier
 * to find. A done item's text is dimmed rather than its tick recoloured twice — the eye is
 * looking for what is LEFT, and dimming what is finished is what puts it there.
 */
export declare function renderChecklist(items: readonly ChecklistItem[], color?: boolean): readonly string[];
/** Shown once, before anything runs, so nobody meets these one surprise at a time. */
export declare function checklistPreamble(color?: boolean): readonly string[];
/** The banner that opens one step, so the run reads as the plan did. */
export declare function stepBanner(item: ChecklistItem, color?: boolean): readonly string[];
/** The line that closes it. */
export declare function stepDone(item: ChecklistItem, ok?: boolean, color?: boolean): string;
/**
 * The whole list again, with a heading that tells the truth about where you are.
 *
 * It said "Final status" at the end of `doctor --fix` — with the organization still
 * to set up, five unticked steps on screen, and the next question already queued.
 * A heading that announces an ending which has not come teaches the reader to
 * distrust the rest of the screen.
 */
export declare function statusSoFar(items: readonly ChecklistItem[], color?: boolean): readonly string[];
/**
 * The end, and meant to be kept — which is why every path is spelled out rather
 * than referred to.
 */
export declare function finalStatus(items: readonly ChecklistItem[], color?: boolean): readonly string[];
/** Shown again as work completes, so "how far along am I" never needs asking. */
export declare function checklistProgress(items: readonly ChecklistItem[], color?: boolean): readonly string[];
