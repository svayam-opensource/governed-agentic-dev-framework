/**
 * What to do now — for the two people who reach the end of setup (#186).
 *
 * It used to end with *"gov is ready in this shell. Try: gov"*, which tells you the
 * tool works and nothing about what you came to do. An adopter has an organization
 * to settle before anyone else can be invited into it; a joiner has none of that
 * and needs the opposite reassurance — that the rules are already decided, and
 * where to read them.
 *
 * Three routes are given for the review, deliberately. The governed one is the
 * point of the framework, and saying so while pretending the other two do not exist
 * would be a lie an admin sees through immediately: they have write access to that
 * repository and will use GitHub or their editor if that is faster. Naming which is
 * governed and which is not respects that, and makes the choice a decision rather
 * than a workaround.
 */
export interface NextStepsFacts {
    readonly orgSlug: string;
    readonly githubOrg: string;
    readonly workspaceRepo: string;
    readonly workspacePath: string;
}
export declare function adopterNextSteps(f: NextStepsFacts, color?: boolean): readonly string[];
export declare function joinerNextSteps(f: NextStepsFacts, color?: boolean): readonly string[];
