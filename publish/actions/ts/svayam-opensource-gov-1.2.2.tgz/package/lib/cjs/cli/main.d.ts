import type { SetupPreAnswers } from "../setup/interview.js";
import { type MenuContext } from "./menu.js";
import { type Reporter } from "./format.js";
/**
 * Give an agent installed beside gov's private Node a way to be found afterwards (#209).
 *
 * The same wrapper `install.sh` writes for `gov`, for the same reason: a symlink would be
 * found and then fail with `env: 'node': No such file or directory`, because Node lives in the
 * directory the wrapper exists to add. Found but unrunnable is worse than not found.
 *
 * RETURNS AN OUTCOME, NOT A NULL — because three very different things used to come back as
 * the same nothing, and the adopter saw the same nothing for all three:
 *
 *   not-ours          the binary is not beside gov's Node; a vendor put it somewhere already
 *                     on PATH, so there is genuinely nothing to do and nothing to say
 *   nowhere-to-link   `~/.local/bin` is not on PATH, so a wrapper there is a file nobody
 *                     finds — the agent will NOT be runnable once gov exits
 *   wrapper-failed    the wrapper was written and could not run, so it was removed
 *
 * The last two have a consequence the adopter meets minutes later; the first has none. This
 * function's own comment used to say that telling them apart was impossible from the screen,
 * "which is how #209's guard no-opped the fix without anyone being able to tell which branch
 * had been taken" — and then it returned `null` for all three anyway. On debian:stable-slim
 * and ubuntu:24.04, where `~/.local/bin` is not on PATH, that produced `✓ Bob Shell 2.0.2
 * installed and runnable` followed by `bob: command not found`, with the only record a `warn`
 * in a log nobody had switched on.
 *
 * Resolved 2026-09-11 with option (b) of the two on the table: gov does NOT start editing shell
 * profiles (POL/#211 — gov does not change what a person's terminal carries after it exits),
 * it SAYS what is true. The caller turns each outcome into the right line.
 *
 * PROVED, NOT ANNOUNCED. If the wrapper cannot run, it is removed and nothing is claimed —
 * `install.sh` does exactly this, and it is the reason gov's own link is trustworthy.
 */
export type LinkOutcome = 
/** A wrapper exists in `dir` and ran; the command works after gov exits. */
{
    readonly kind: "linked";
    readonly dir: string;
}
/** Not beside gov's Node — already reachable by whatever put it there. Say nothing. */
 | {
    readonly kind: "not-ours";
}
/** `dir` is not on PATH, so nothing was written. `nodeBin` is where the binary actually is. */
 | {
    readonly kind: "nowhere-to-link";
    readonly dir: string;
    readonly nodeBin: string;
}
/** A wrapper was written in `dir`, did not run, and was removed. */
 | {
    readonly kind: "wrapper-failed";
    readonly dir: string;
    readonly nodeBin: string;
};
/**
 * What to tell the adopter about an agent gov installed but cannot put on their PATH.
 *
 * Kept separate from the writing so it can be tested without a filesystem, and so the wording
 * lives next to the outcome it explains rather than inside an `if` in a 400-line flow.
 * Returns no lines for the two outcomes that need none.
 */
export declare function linkOutcomeLines(o: LinkOutcome, cmd: string, r: Reporter): readonly string[];
/**
 * `gov setup` — the interactive workspace BOOTSTRAP (port of setup.sh). Async
 * (readline prompts), so bin.ts routes it here instead of through resolution.
 * Runs in cwd (the cloned framework repo), before any resolution.
 */
export declare function runSetupCommand(argv: readonly string[], now?: string, cwd?: string, 
/** Answers already collected by the org interview — nothing here is asked again. */
pre?: SetupPreAnswers): Promise<number>;
/**
 * FIRST RUN — the real environment behind {@link runFirstRun}. Returns null when an org is already
 * registered and active, which is the overwhelmingly common case and costs two file reads.
 *
 * Everything interesting lives in bootstrap.ts, which knows nothing about git, disks or terminals. This
 * function is the part that cannot be unit-tested, so it is kept to plumbing with no decisions in it.
 */
export declare function runFirstRunIfNeeded(now?: string): Promise<number | null>;
/** Read the CLI's own version from its package.json. Walks up from this module
 *  so it resolves in both the built layout (lib/esm/cli) and src-via-tsx. */
export declare function readCliVersion(): string;
/** Gather the best-effort banner context for the interactive menu (all optional). */
export declare function gatherMenuContext(): Promise<MenuContext>;
/**
 * `gov work [--project=<regex>] [--agent=<kind>] [--seed] [--print-prompt]` — the one command.
 *
 * It walks the state ladder and does the missing rungs: not cloned → join; not started → seed (with
 * consent); ready → launch the agent with the session-start prompt. Both flags are optional; supply both
 * and it runs start to finish without a prompt, which is what makes it usable from a script.
 *
 * WITH NO TERMINAL, an unresolved choice FAILS NAMING THE FLAG that would have resolved it. It does not
 * guess a project or an agent: there is nobody to correct a wrong guess, and a session started on the wrong
 * project is worse than no session.
 */
/**
 * `gov agent install <id>` — lifted out of the router for the reason the router itself gives
 * for `work`: it asks questions and it spawns things, and neither belongs in a pure route.
 *
 * It also gets to OWN the terminal here. That is the whole of #213: one reader per run, and
 * everything that needs to ask borrows it. When this ran through `route` it had no reader of
 * its own and reached for the terminal directly — which was harmless standing alone and lost
 * a race the moment the same code was reached from the menu.
 */
export declare function runAgentInstall(argv: readonly string[]): Promise<number>;
export declare function runWork(argv: readonly string[]): Promise<number>;
/** Route any command (setup / normal) — used by the menu. There is no plugin routing: `auth`, `creds`,
 *  the deploy verbs and the infra verbs belong to the other clients and are invoked directly
 *  (adr-three-clients, PRJ-43). */
export declare function runAny(argv: readonly string[]): Promise<number> | number;
/** All commands in reference order (for the Help → "help for one command" picker). */
export declare const helpCommandNames: () => string[];
/** The command reference shown under the Help menu (git-help style), or per-command help. */
export declare function helpLines(command?: string): string[];
/** Build + run the interactive main menu (no-args TTY). Async — routed from bin.ts. */
export declare function runMainMenu(): Promise<number>;
/**
 * The `gov-work` entry point. Returns a process exit code. `now` is injected (an
 * ISO-8601 instant) so the composition stays deterministic + testable.
 */
export declare function main(argv: readonly string[], now?: string): number;
