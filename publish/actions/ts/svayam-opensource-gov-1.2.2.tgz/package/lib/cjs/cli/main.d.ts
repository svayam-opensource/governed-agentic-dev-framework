import { type MenuContext } from "./menu.js";
/**
 * `gov setup` — the interactive workspace BOOTSTRAP (port of setup.sh). Async
 * (readline prompts), so bin.ts routes it here instead of through resolution.
 * Runs in cwd (the cloned framework repo), before any resolution.
 */
export declare function runSetupCommand(argv: readonly string[], now?: string, cwd?: string): Promise<number>;
/**
 * FIRST RUN — the real environment behind {@link runFirstRun}. Returns null when an org is already
 * registered and active, which is the overwhelmingly common case and costs two file reads.
 *
 * Everything interesting lives in bootstrap.ts, which knows nothing about git, disks or terminals. This
 * function is the part that cannot be unit-tested, so it is kept to plumbing with no decisions in it.
 */
export declare function runFirstRunIfNeeded(now?: string): Promise<number | null>;
/** Read the CLI's own version from its package.json. Walks up from this module
 *  so it resolves in both the built layout (lib/esm/cli) and src-via-tsx. */
export declare function readCliVersion(): string;
/** Gather the best-effort banner context for the interactive menu (all optional). */
export declare function gatherMenuContext(): Promise<MenuContext>;
/**
 * `gov work [--project=<regex>] [--agent=<kind>] [--seed] [--print-prompt]` — the one command.
 *
 * It walks the state ladder and does the missing rungs: not cloned → join; not started → seed (with
 * consent); ready → launch the agent with the session-start prompt. Both flags are optional; supply both
 * and it runs start to finish without a prompt, which is what makes it usable from a script.
 *
 * WITH NO TERMINAL, an unresolved choice FAILS NAMING THE FLAG that would have resolved it. It does not
 * guess a project or an agent: there is nobody to correct a wrong guess, and a session started on the wrong
 * project is worse than no session.
 */
export declare function runWork(argv: readonly string[]): Promise<number>;
/** Route any command (setup / normal) — used by the menu. There is no plugin routing: `auth`, `creds`,
 *  the deploy verbs and the infra verbs belong to the other clients and are invoked directly
 *  (adr-three-clients, PRJ-43). */
export declare function runAny(argv: readonly string[]): Promise<number> | number;
/** All commands in reference order (for the Help → "help for one command" picker). */
export declare const helpCommandNames: () => string[];
/** The command reference shown under the Help menu (git-help style), or per-command help. */
export declare function helpLines(command?: string): string[];
/** Build + run the interactive main menu (no-args TTY). Async — routed from bin.ts. */
export declare function runMainMenu(): Promise<number>;
/**
 * The `gov-work` entry point. Returns a process exit code. `now` is injected (an
 * ISO-8601 instant) so the composition stays deterministic + testable.
 */
export declare function main(argv: readonly string[], now?: string): number;
