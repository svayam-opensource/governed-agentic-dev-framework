/**
 * The interactive menu (`gov-work` with no args on a TTY) — a TASK-ORIENTED on-ramp
 * (mirrors the legacy `prj` menu), not a command index. The goal is to get a
 * developer working fast:
 *   Status  → review (list · list-all · status)
 *   Work    → GUIDED flow: pick your project → seed-if-new / continue → session-start
 *   Admin   → curated governance actions (manage · knowledge · onboard · …)
 *   Help    → the full command reference (for agents/devs working in TTY)
 * Rendering + choice-resolution are pure/testable; runMenu delegates the guided
 * flows + command runs to injected handlers. (Enterprise catalog/deploy is a
 * SEPARATE CLI, `gov-cicd` — this menu has no knowledge of it.)
 */
import { type AskFns } from "./ask.js";
export type ContextMode = "project" | "governed" | "none";
export interface MenuContext {
    readonly orgName?: string;
    readonly githubOrg?: string;
    readonly branch?: string;
    readonly user?: string;
    readonly workspaceCount?: number;
    readonly cliVersion?: string;
    /** PROJECT (cwd inside a project) · GOVERNED (org home) · NONE (no workspace). Drives menu adaptation. */
    readonly mode?: ContextMode;
    /** the current project id, when mode === "project". */
    readonly project?: string;
}
/** A command is visible only in these context modes; absent = every mode. See [[context-scoped-menu]]. */
export type Scope = ContextMode;
/** `argHint` = the single positional SUBJECT; `flagArgs` = the named-flag qualifiers (prompted per value).
 *  A `kind:"env"` flag is rendered as a context-scoped picker (PROJECT→local; GOVERNED→dev/uat/prod). */
export interface MenuFlagArg {
    readonly name: string;
    readonly hint: string;
    readonly optional?: boolean;
    readonly kind?: "env";
}
/** When a command's SUBJECT has a discoverable value set, the menu offers a picker instead of free-typing:
 *  `project` → the user's assigned projects; `unit` → the catalog's units (§2 value discovery). */
export type SubjectKind = "project" | "unit";
export interface SubCommand {
    readonly cmd: string;
    readonly desc: string;
    readonly argHint?: string;
    readonly flagArgs?: readonly MenuFlagArg[];
    readonly subs?: readonly SubCommand[];
    readonly scopes?: readonly Scope[];
    readonly subjectKind?: SubjectKind;
}
export type MenuAction = {
    readonly kind: "guided";
    readonly key: "work";
    readonly label: string;
    readonly desc: string;
    readonly hint: string;
    readonly scopes?: readonly Scope[];
} | {
    readonly kind: "submenu";
    readonly key: "admin";
    readonly label: string;
    readonly desc: string;
    readonly commands: readonly SubCommand[];
    readonly scopes?: readonly Scope[];
} | {
    readonly kind: "help";
    readonly key: "help";
    readonly label: string;
    readonly desc: string;
    readonly hint: string;
    readonly scopes?: readonly Scope[];
};
/** The FULL main-menu definition (every mode) — gov-work's OWN verbs, and only those. The menu used to
 *  merge submenus discovered from the gov-cicd and do-admin plugins; the three clients each render their
 *  own menu now (adr-three-clients, PRJ-43). Use `visibleActions(ctx)` for the context-filtered list.
 *
 *  The STATUS submenu (list · list-all · status) went on 2026-08-07: who is assigned what, and how a project
 *  is doing, are the WORK-MANAGEMENT system's answers — GitHub's today, Jira's next. gov asks that system;
 *  it does not keep its own view of it. The reads survive inside the work-mgmt port (this menu's own project
 *  picker is one), so nothing is lost except a place to type them. */
export declare function mainActions(): MenuAction[];
/** The context-filtered action list (HARD-HIDE): drops out-of-scope commands and any submenu left empty.
 *  This is the single source of menu numbering — format / resolve / run all go through it. */
export declare function visibleActions(ctx: MenuContext): MenuAction[];
/** The env choices offered for a `kind:"env"` flag in this context (PROJECT = local only; else dev/uat/prod). */
export declare function contextEnvs(mode: ContextMode | undefined): string[];
export declare function formatMainMenu(ctx: MenuContext): string[];
export type TopChoice = {
    readonly kind: "action";
    readonly action: MenuAction;
} | {
    readonly kind: "org";
} | {
    readonly kind: "quit";
} | {
    readonly kind: "unknown";
};
export declare function resolveTopChoice(input: string, ctx?: MenuContext): TopChoice;
/** The shared prompt/print the guided flows use (from runMenu's readline). */
export interface MenuIo {
    readonly prompt: (q: string) => Promise<string>;
    readonly print: (l: string) => void;
    /**
     * The same reader, with a hidden variant for a key (#213).
     *
     * The menu's readline stays open for the whole loop, so anything it hands off to must ask
     * THROUGH it. A handler that opened its own reader raced this one for the same keystrokes
     * and lost — the sign-in choice answered itself and an adopter fell through to a browser
     * screen they could not use.
     */
    readonly ask: AskFns;
}
/** Handlers the readline loop delegates to (all injected → testable). */
export interface MenuHandlers {
    /** Run a command chosen from a submenu (delegates to the CLI). */
    readonly runCommand: (argv: readonly string[]) => Promise<number> | number;
    /** The guided Work flow (pick project → seed/continue → session-start). */
    readonly runWork: (io: MenuIo) => Promise<number>;
    /** Switch the active org. */
    readonly switchOrg: (org: string) => Promise<number> | number;
    /** Help lines — full reference when no command, else per-command help. */
    readonly help: (command?: string) => readonly string[];
    /** All command names, in reference order — for the "help for one command" picker. */
    readonly helpCommands: () => readonly string[];
    /** Registered governance workspaces — for the org switcher (so the user picks, not types the exact name). */
    readonly listOrgs: () => readonly {
        readonly org: string;
        readonly home: string;
    }[];
    /** Discoverable subject value sets for the pickers (§2). Called on demand (a `gh` call may be slow). */
    readonly listMyProjects?: () => readonly string[];
}
export declare function runMenu(ctx: MenuContext, h: MenuHandlers): Promise<number>;
