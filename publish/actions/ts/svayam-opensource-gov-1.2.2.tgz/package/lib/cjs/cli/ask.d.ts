/**
 * ONE READER, ALWAYS — and a hidden variant of it for a key (#213, #194).
 *
 * This exists because the same mistake was made three times in three different ways, and each
 * time the symptom was a prompt that answered itself:
 *
 *   #194  a question asked on /dev/tty while `runWorkFlow` held a readline. The empty read was
 *         taken for "yes" and recorded a repository mapping nobody had agreed to. Twice.
 *   #213  the sign-in choice read `readSync(0, …)` while the same readline was live. It
 *         returned nothing instantly, so an adopter who typed 2 was never asked for a key.
 *   #213  the fix for that opened a SECOND handle on /dev/tty. Better, and still two readers:
 *         it survived `gov work` (whose readline had never been used) and lost on the menu
 *         path (whose readline stays open across the whole loop), which is the path adopters
 *         actually take.
 *
 * The rule that removes the class: whoever owns the terminal does the asking, and everything
 * that needs to ask BORROWS that owner. Never open a second reader, however carefully.
 */
import * as readline from "node:readline";
export interface AskFns {
    /** Ask, and let the answer echo — the reader needs to see what they typed. */
    readonly line: (question: string) => Promise<string>;
    /** Ask with the echo off. A key must not reach the screen, the scrollback, or a shoulder. */
    readonly secret: (question: string) => Promise<string>;
}
/**
 * Build both from an existing readline and the `prompt` already derived from it.
 *
 * THE HIDDEN READ MUTES THE INTERFACE RATHER THAN THE TERMINAL. `stty -echo` acts on a
 * terminal device, which is the wrong object here: the question is being asked by a readline
 * whose output we control, and a process that turns the terminal's echo off owes the terminal
 * a restoration on every path — including a throw, a Ctrl-C, and a crash. Overriding what the
 * interface writes has none of that liability and needs no `finally` to be correct.
 */
export declare function askFns(rl: readline.Interface, prompt: (q: string) => Promise<string>): AskFns;
