import { type ParsedArgs } from "./args.js";
import type { OrgConfig } from "../config/org-config.js";
import type { Board } from "../lifecycle/board.js";
import type { Vcs } from "../lifecycle/vcs.js";
import type { Fs } from "../lifecycle/fs-io.js";
import type { Issues } from "../lifecycle/issues.js";
import type { AnchorCreator } from "../lifecycle/anchor.js";
import type { Pulls } from "../lifecycle/pulls.js";
import type { BoardRef } from "../lifecycle/identity.js";
import type { GateResult } from "../lifecycle/close-gate.js";
import { planAgentInstall } from "./agent-verb.js";
import { type OrgDeps } from "../resolve/org.js";
import type { Projects } from "../lifecycle/project-list.js";
/** Everything the router needs: config, the resolved workspace, identity + ports. */
export interface CliContext {
    readonly config: OrgConfig;
    /** The resolved gov workspace — the gov HOME for seed, else the project clone. */
    readonly home: string;
    readonly today: string;
    /** The current user's git email — recorded as seeded_by. */
    readonly seededBy: string;
    /** The current user's gh login — the default issue assignee / anchor assignee. */
    readonly login?: string;
    readonly identity?: {
        name?: string;
        email?: string;
    };
    readonly board: Board;
    readonly vcs: Vcs;
    readonly fs: Fs;
    readonly issues: Issues;
    readonly anchor: AnchorCreator;
    readonly pulls: Pulls;
    readonly projects: Projects;
    readonly cloneRepo: (url: string, dest: string) => void;
    /** Write access + a fork under this org, per repo (#194). Absent → branch checks only. */
    readonly repoStanding?: (url: string, githubOrg: string) => {
        readonly canPush: boolean;
        readonly forkUnderOrg: string | null;
    } | undefined;
    /**
     * Ask whether to record a fork mapping, and write it to org-config.yaml on yes
     * (#194). Returns whether anything was written. Absent → the message stands on
     * its own and the adopter edits the file themselves.
     */
    /** Record what the preflight proposed, for the caller that owns the terminal to ask about (#194). */
    readonly noteRepoOverrides?: (proposed: readonly {
        readonly from: string;
        readonly to: string;
    }[]) => void;
    /** Is this command on PATH? The same probe the work flow uses (#195/#196). */
    readonly hasTool?: (cmd: string) => boolean;
    /** The org's approved-agent block, or null when the policy carries none (#196). */
    readonly approvedAgents?: () => readonly {
        readonly id: string;
        readonly default?: boolean;
    }[] | null;
    /** Does the backup copy of this agent's key differ from the one it uses? Never the values. */
    readonly credentialDrift?: (agentId: string) => boolean;
    /** Run an install plan, and offer the sign-in. Owns the terminal; returns success. */
    /**
     * Absent by design since #213: installing ASKS and SPAWNS, so `bin.ts` handles
     * `agent install` before routing — next to `work`, for the reason stated below.
     */
    readonly performAgentInstall?: (plan: ReturnType<typeof planAgentInstall>) => boolean;
    /** Raise a pull request adding an agent to llm-governance.md. */
    readonly proposeAgentApproval?: (id: string) => readonly string[];
    /** REQUIRED (C01) — write-access to the GitHub Project (viewerCanUpdate). The lifecycle ops call it
     *  unconditionally; wiring it here is what makes the CLI actually ENFORCE authorization. */
    readonly authorize: (ref: BoardRef) => boolean;
    /** REQUIRED — close's test-merge gate (governance.runSuite). Always run before any push. */
    readonly gate: () => GateResult;
    readonly log?: (msg: string) => void;
}
export interface CommandResult {
    readonly code: number;
    readonly lines: readonly string[];
}
/**
 * Route `prj org …` — the multi-home registry commands. Handled SEPARATELY from
 * {@link route} because they run WITHOUT a resolved workspace (`gov org add` is
 * the bootstrap that makes resolution work).
 */
export declare function routeOrg(positionals: readonly string[], flags: ParsedArgs["flags"], deps: OrgDeps): CommandResult;
/** Route a parsed command to its orchestrator; returns an exit code + output. */
export declare function route(parsed: ParsedArgs, ctx: CliContext): CommandResult;
