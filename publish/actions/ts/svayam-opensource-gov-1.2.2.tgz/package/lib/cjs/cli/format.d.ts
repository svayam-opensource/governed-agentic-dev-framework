/**
 * How a step reads while it runs (#204).
 *
 * Borrowed, deliberately, from IBM's Bob installer — which an adopter walking our path found
 * markedly easier to follow, and the difference was presentation rather than content:
 *
 *     Verifying Package Integrity          a NAMED PHASE, set off by blank lines
 *
 *     -> Fetching package checksum...      the arrow is under way, or informational
 *     ok Expected SHA256: ffaf815f...      the tick is a fact that is now true
 *
 * Two marks with two meanings is the whole idea. Ours used the tick for a finished step AND
 * for a heading, so the eye had nothing to sort by; and the output was dense enough that the
 * five-minute browser sign-in arrived with no visual break before it — which is how the PATH
 * reminder went unread in #186.
 *
 * The checklist (`checklist.ts`) answers "where am I in the whole run". This answers the same
 * question inside ONE step, and the two must not compete: no rules, no boxes, no second
 * numbering. A phase title and two marks.
 *
 * COLOUR IS THE SAME DISTINCTION, NOT DECORATION — and never the only carrier of meaning,
 * because it is the part most likely to be absent.
 */
/** Should this stream carry ANSI at all? */
export interface ColorFacts {
    /** is the destination a terminal? a pipe or a log file is not. */
    readonly isTty: boolean;
    /** the environment — `NO_COLOR`, `TERM`, `FORCE_COLOR` are read from it. */
    readonly env: Readonly<Record<string, string | undefined>>;
}
/**
 * `NO_COLOR` wins over everything except an explicit `FORCE_COLOR`, per no-color.org: it is
 * set by people who cannot read coloured output, and a tool that overrides it is not offering
 * a preference. `TERM=dumb` is the same answer from the terminal rather than the person.
 */
export declare function useColor(f: ColorFacts): boolean;
declare const CODES: {
    readonly reset: "\u001B[0m";
    readonly bold: "\u001B[1m";
    readonly dim: "\u001B[2m";
    readonly green: "\u001B[32m";
    readonly yellow: "\u001B[33m";
    readonly red: "\u001B[31m";
    readonly cyan: "\u001B[36m";
};
export type Ink = keyof Omit<typeof CODES, "reset">;
/** Wrap in an ANSI code, or return the text untouched. The only place a code is written. */
export declare function paint(text: string, ink: Ink, on: boolean): string;
/**
 * The vocabulary. Each returns LINES, so a caller composes them without deciding where the
 * blank lines go — that decision is what makes the phases legible, and it belongs here.
 */
export interface Reporter {
    /** A named phase: blank line, title, blank line. The reader's "where am I". */
    phase(title: string): readonly string[];
    /** Under way, or something worth knowing while waiting. */
    step(text: string): string;
    /** True as of now. Say WHAT is true — "Bob Shell 2.0.2 installed" beats "installed". */
    ok(text: string): string;
    /** Did not happen. Colour is the least of what says so; the mark and the words carry it. */
    fail(text: string): string;
    /**
     * It happened, AND there is a consequence the reader will meet later.
     *
     * The gap between `ok` and `fail` is where #209 lived: gov installed an agent successfully
     * and could not put it on the adopter's PATH, so `ok` was a half-truth and `fail` was wrong.
     * With only two marks the honest line had nowhere to go, and the code said nothing at all —
     * leaving `✓ installed and runnable` as the last word before `bob: command not found`.
     */
    warn(text: string): string;
    /** The end of a phase that succeeded, when the phase deserves an ending. */
    complete(text: string): readonly string[];
}
export declare function reporter(color: boolean): Reporter;
export {};
