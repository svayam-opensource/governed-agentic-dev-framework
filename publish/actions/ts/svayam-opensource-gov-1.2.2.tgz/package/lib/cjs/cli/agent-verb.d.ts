/**
 * `gov agent` — the door that stays open (#196, Q1).
 *
 * Agent help used to exist for about ten seconds: the moment the Work flow found a
 * prepared project and nothing to run in it. Decline once and there was no way back;
 * want a second agent later and there was no way in; ask "which agents may I use
 * here?" and there was nothing to ask.
 *
 * So the same flow gets a verb as well as a step in adoption. One code path, two
 * doors — reporting is pure and lives here; installing and signing in are performed
 * by the caller, which owns the terminal.
 *
 *   gov agent                what is approved, installed, signed in
 *   gov agent install <id>   install an approved agent
 *   gov agent approve <id>   propose adding one — a pull request, not an edit
 */
import { type AgentCandidate, type VariantStatus } from "./agent-catalog.js";
import { type ApprovedAgent } from "../config/approved-agents.js";
export interface AgentReportFacts {
    /** The org's block, or null when the policy carries none. */
    readonly approved: readonly ApprovedAgent[] | null;
    readonly hasTool: (cmd: string) => boolean;
    readonly env: Readonly<Record<string, string | undefined>>;
    /** Whether the backup copy of a key differs from the agent's own — never its value. */
    readonly credentialDrift?: (agentId: string) => boolean;
}
export interface AgentRow {
    readonly agent: AgentCandidate;
    readonly isDefault: boolean;
    readonly variants: readonly VariantStatus[];
    readonly runnable: readonly VariantStatus[];
    readonly credentialPresent: boolean | null;
    readonly credentialDrifted: boolean;
}
export interface AgentReport {
    readonly rows: readonly AgentRow[];
    /** Approved agents the framework has no harness for — should be impossible; reported if it happens. */
    readonly unknownIds: readonly string[];
    readonly usingDefaults: boolean;
}
export declare function agentReport(f: AgentReportFacts): AgentReport;
export declare function formatAgentReport(r: AgentReport): readonly string[];
/** What `install` will do, decided before anything runs. */
/**
 * A route gov could take if a host editor existed — stated instead of skipped (#221).
 *
 * The plan used to `continue` past an extension variant with no host, so the route vanished and
 * the report said only "needs VS Code or Cursor". That is true and it is a dead end: an adopter
 * on a desktop machine with no editor yet is told what is missing and left there, and gov never
 * checks back. Naming it here lets the caller offer to guide the install and then RE-PROBE,
 * which is the part that turns a refusal into a step.
 */
export interface HostNeeded {
    /** the variant's label, e.g. "in VS Code" */
    readonly what: string;
    /** commands that would satisfy it, in preference order — `code`, `cursor`, `windsurf` */
    readonly hosts: readonly string[];
    readonly extensionId: string;
}
export type InstallPlan = {
    readonly ok: false;
    readonly message: string;
} | {
    readonly ok: true;
    readonly agent: AgentCandidate;
    readonly steps: readonly {
        readonly what: string;
        readonly command: readonly string[];
    }[];
    readonly signIn: readonly string[] | null;
    readonly signupUrl: string | null;
    /** Routes waiting on a host editor. Empty when every route is runnable as-is. */
    readonly hostNeeded: readonly HostNeeded[];
};
export declare function planAgentInstall(id: string, approved: readonly ApprovedAgent[] | null, hasTool: (cmd: string) => boolean): InstallPlan;
