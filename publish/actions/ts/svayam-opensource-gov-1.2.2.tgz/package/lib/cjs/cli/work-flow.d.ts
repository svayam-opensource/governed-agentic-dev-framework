import type { Projects } from "../lifecycle/project-list.js";
import type { AnchorCreator } from "../lifecycle/anchor.js";
import type { Fs } from "../lifecycle/fs-io.js";
import { ensureRootProtocol } from "../lifecycle/root-protocol.js";
import { type AgentCandidate } from "./agent-catalog.js";
/**
 * The status of a board that has NO anchor issue: nobody has seeded it, anywhere, ever.
 *
 * Named rather than spelled out at each site (#198), because it is the ONE value that separates
 * "does not exist yet" from "exists, and this machine has not opened it". `deriveStatus` never
 * produces it — a project with an anchor always has a real lifecycle status.
 */
export declare const NOT_STARTED = "not started";
export interface WorkProject {
    readonly boardNumber: number;
    readonly title: string;
    readonly url: string;
    /** A `ProjectStatus` when an anchor issue exists, {@link NOT_STARTED} when none does. */
    readonly status: string;
    readonly projectId: string;
}
export interface WorkFlowDeps {
    readonly projects: Projects;
    readonly anchor: AnchorCreator;
    readonly fs: Fs;
    readonly config: {
        readonly githubOrg: string;
        readonly workspaceRepo: string;
        readonly agentWorkRoot: string;
        readonly ownerField?: "organization" | "user";
    };
    readonly me: string | null;
    readonly canWriteBoard: (boardNumber: number) => boolean;
    readonly run: (argv: readonly string[]) => Promise<number> | number;
    readonly prompt: (q: string) => Promise<string>;
    /** Is this command on PATH? Injected, so the menu is decidable in a test (#195). */
    readonly hasTool?: (cmd: string) => boolean;
    /** The environment, for reporting a missing key without ever reading its value. */
    readonly env?: Readonly<Record<string, string | undefined>>;
    /** The org's approved_agents block, or null when the policy carries none (#196). */
    readonly approvedAgents?: () => readonly {
        readonly id: string;
        readonly default?: boolean;
    }[] | null;
    /** This person's preferred agent id, from their preferences file. C03. */
    readonly agentPreference?: () => string | null;
    /** Install an approved agent and offer its sign-in. Returns whether it is usable now. */
    /**
     * Install an approved agent and settle its sign-in. Returns whether it is usable now.
     *
     * ASYNC, AND IT BORROWS THIS FLOW'S PROMPT (#213). It used to be synchronous and read the
     * terminal itself — first `readSync(0, …)`, which the flow's own readline had already taken,
     * then a second handle on /dev/tty, which raced the same readline for the same keystrokes.
     * Both are the shape #194 named: two readers of one terminal. There is one reader here, and
     * everything that needs to ask borrows it.
     */
    readonly installAgent?: (id: string, ask: AskFns) => Promise<boolean> | boolean;
    /** Fork mappings the last `seed` proposed, if any (#194). */
    readonly pendingRepoOverrides?: () => readonly {
        readonly from: string;
        readonly to: string;
    }[];
    /** Record them in org-config.yaml. Returns whether anything was written. */
    readonly applyRepoOverrides?: (o: readonly {
        readonly from: string;
        readonly to: string;
    }[]) => boolean;
    readonly print: (l: string) => void;
    /** May this flow's output carry ANSI (#204)? Decided by the caller — these lines go to stderr. */
    readonly color?: boolean;
    /**
     * How to ask — including the hidden read a key needs. REQUIRED, and that is the fix.
     *
     * It was optional, with a fallback that printed "(cannot hide input here — skipped)" and
     * returned "". Three call sites build a work flow; two were given an asker and the THIRD —
     * the review offer that closes adoption (#203) — was not. So an adopter chose "paste an API
     * key", and the fallback answered for them, in a parenthetical, and the run carried on.
     *
     * That is #199's lesson rebuilt by hand: a degraded path that cannot be told from success at
     * the call site. Making this required turns "I forgot one" into a compile error, which is
     * the only version of this that stays fixed.
     */
    readonly ask: AskFns;
    /** Launch an interactive agent/editor/shell with `cwd` = the project dir. `inject` = the session-start
     *  kickoff prompt handed to a speak-first CLI agent (Claude / cursor-agent) so it runs the protocol
     *  immediately. Terminal agents inherit stdio + block; the GUI editor opens detached. */
    readonly launch: (agent: AgentKind, cwd: string, inject: string) => Promise<number>;
    /** `--print-prompt` writes HERE, not through `print` — stdout must carry the prompt and nothing else,
     *  so `gov work … --print-prompt` can be captured or piped. */
    readonly printPrompt?: (prompt: string) => void;
}
/**
 * What to launch: an `AGENT_CATALOG` id (`"claude-code"`, `"ibm-bob"`, …) whose own `cmd` is run,
 * or one of the two things that are not catalog agents — the Cursor editor opened on the project
 * directory, and a plain shell.
 *
 * It was a closed four-value union, which is why the catalog could grow to twelve agents while only
 * two of them could be started (#199). The id IS the launch instruction now; nothing translates it.
 */
export type AgentKind = "cursor-gui" | "shell" | (string & {});
/**
 * The two ways to ask, both driven by the ONE reader the flow owns.
 *
 * `secret` is the same question with the echo off — a key must not appear on screen, in a
 * scrollback, or over someone's shoulder.
 */
export interface AskFns {
    readonly line: (question: string) => Promise<string>;
    readonly secret: (question: string) => Promise<string>;
}
/**
 * What `gov work` already knows, so the flow can skip asking. The MENU passes none of these and behaves
 * exactly as before; flags fill them in one at a time, and with both supplied the flow runs start to finish
 * without a prompt — which is what makes it usable from a script.
 */
export interface WorkFlowOpts {
    /** `--project=<regex>` — matched against project ids, case-insensitive. */
    readonly projectPattern?: string;
    /** `--agent=<kind>` — skips the agent question. */
    readonly agent?: AgentKind;
    /** `--seed` — authorises STARTING a project that nobody has seeded yet (org-visible: branches, anchor
     *  issue, assignment). Picking a `(not started)` entry from the menu IS this consent; a regex match is not. */
    readonly seedOk?: boolean;
    /** `--print-prompt` — emit the kickoff prompt and stop. Seeds nothing, clones nothing, launches nothing. */
    readonly printPromptOnly?: boolean;
    /** false when there is no TTY: an unresolved choice must then FAIL naming the flag that would resolve it,
     *  because there is nobody to ask. */
    readonly interactive?: boolean;
}
/**
 * Projects whose id matches `pattern` — a regex, so `43` finds `PRJ-43-…` and a full id still matches
 * itself. An invalid regex is matched LITERALLY rather than throwing: someone typing `gov work
 * --project=portal(v2` wants a project, not a lecture about escaping.
 */
export declare function matchProjects<T extends {
    readonly projectId: string;
}>(items: readonly T[], pattern: string): T[];
/** The kickoff prompt that makes a speak-first CLI agent run the session-start protocol immediately, before
 *  the user types anything (ports the bash prj `agent_session_start_prompt`). Paths are workspace-relative
 *  from the PROJECT ROOT (where the agent launches), so the agent reads the right files across repos. */
export declare function sessionStartPrompt(projectId: string, workspaceRepo: string): string;
export interface StartSession {
    readonly projectId: string;
    /** the project directory the agent must run in — repos are its children. */
    readonly dir: string;
    /** the kickoff prompt, identical to the one the interactive menu injects. */
    readonly prompt: string;
}
/**
 * WHAT A SESSION ON AN EXISTING PROJECT NEEDS — resolved without a terminal.
 *
 * The guided Work flow (menu) does seed → join → session-start and launches an agent carrying the kickoff
 * prompt. That path is TTY-only, which is backwards: the prompt exists to drive an AGENT, and agents are
 * precisely the non-TTY case. This is the same resolution as a pure function, so `gov work` can answer a
 * script, a CI job, or an agent wrapper.
 *
 * `undefined` when the project is not cloned here — the caller says how to get it (`gov join <board-url>`),
 * because "no such directory" is not a useful thing to tell someone who asked to start work.
 */
export declare function startSession(projectWorkRoot: string, workspaceRepo: string, projectId: string, exists: (p: string) => boolean): StartSession | undefined;
/**
 * The project a path sits inside, if any: the first segment below the work root. Lets `gov work` be typed
 * with no argument from anywhere in a project — the same rule the context banner uses to decide PROJECT.
 */
export declare function projectFromPath(projectWorkRoot: string, cwd: string, sep?: string): string | undefined;
export interface LaunchSpec {
    readonly cmd: string;
    readonly args: readonly string[];
    readonly detached: boolean;
    /**
     * The kickoff prompt gov could NOT hand to this agent, because its catalog entry does not
     * say how (#207). The caller prints it to paste. Absent when the prompt was passed.
     */
    readonly promptToPaste?: string;
    /** True when the prompt travelled in `args` — so the caller can say governance happened. */
    readonly promptArgvUsed?: true;
}
/**
 * The concrete command to launch an agent in a project dir — READ FROM THE CATALOG (#199).
 *
 * It used to be a four-arm switch, and every catalog agent was squeezed into those four values by a
 * ternary that mapped anything but Claude Code and Cursor to `"shell"`. So five of the seven `cli`
 * agents — codex, gemini, copilot, bob, aider — installed, were announced as started, and opened a
 * bare shell. Each of them carries its own `cmd` in `AGENT_CATALOG`, which the mapping discarded.
 *
 * NULL WHEN GOV CANNOT LAUNCH IT. The defect was not the missing binary, it was the fallback:
 * substituting a shell produced a result indistinguishable from success, and the caller went on to
 * say the agent had started. A caller that must handle null cannot make that mistake silently.
 *
 * Speak-first CLI agents get the `inject` prompt as their first message; an `ide` entry opens the
 * directory and detaches. Pure (env + catalog injected), so the mapping is tested without spawning.
 */
export declare function agentLaunchSpec(agent: AgentKind, cwd: string, inject: string, env?: NodeJS.ProcessEnv, catalog?: readonly AgentCandidate[]): LaunchSpec | null;
/**
 * The `--agent=` vocabulary. The flag is a short alias a person types; the value gov carries is the
 * CATALOG ID, so the launch can read the entry. Catalog ids are accepted directly too, which is what
 * makes `--agent=ibm-bob` work without a second name for it.
 */
export declare const AGENT_FLAG_ALIASES: Readonly<Record<string, AgentKind>>;
/** A flag or `$GOV_AGENT` value → the catalog id (or special) to launch, or null if it names nothing. */
export declare function agentKindFromFlag(named: string, catalog?: readonly AgentCandidate[]): AgentKind | null;
/**
 * WHICH AGENT TO LAUNCH, without asking — the non-TTY counterpart of the menu's numbered prompt.
 *
 *   --agent <kind>  >  $GOV_AGENT  >  the one that is actually installed
 *
 * The last step is what makes this work for someone who has just installed gov: if exactly one supported
 * agent is on their PATH, that is not a guess, it is the only answer. Two installed and no preference is a
 * real ambiguity, so it asks rather than picking — the same discipline as refusing an ambiguous content_sha.
 */
export type AgentChoice = {
    readonly ok: true;
    readonly agent: AgentKind;
} | {
    readonly ok: false;
    readonly reason: string;
};
export declare function resolveAgent(flag: string | undefined, env: NodeJS.ProcessEnv, onPath: (cmd: string) => boolean, catalog?: readonly AgentCandidate[]): AgentChoice;
/** My projects = open boards whose anchor issue lists me as an assignee (owner). */
export declare function myProjects(deps: WorkFlowDeps): WorkProject[];
/** Seedable boards = open boards I can WRITE but that have NO anchor yet (never seeded). Offered in Work so a
 *  freshly-created GitHub board (e.g. #106) can be STARTED, not only picked once already seeded. Picking one
 *  runs the not-seeded → `seed` path. (Cost: `canWriteBoard` per un-anchored board — batch if it gets slow.) */
export declare function seedableBoards(deps: WorkFlowDeps): WorkProject[];
export type WorkspaceState = "not-seeded" | "not-cloned" | "ready";
/**
 * Where this project stands ON THIS MACHINE — and, separately, whether it exists at all (#198).
 *
 * The local directory answers only the first question. It was being used for both, so on a machine
 * that had never opened the project — every fresh install, every new developer — an organization's
 * long-seeded projects were all classified `not-seeded` and routed to `seed`. Seed then found the
 * remote branch and the home stub, which are the evidence the seed SUCCEEDED, and reported them as
 * "leftover state from a previous failed run". The run stopped there, offering nothing.
 *
 * Whether a project has been seeded is a GitHub fact, and the list one line above already resolved
 * it: an anchor issue exists (`myProjects` → a real status) or it does not (`seedableBoards` →
 * "not started"). So it is read here rather than guessed from the filesystem. A missing directory
 * for an anchored project means it is not cloned HERE, which is `join`'s job — and `join`
 * materializes the work root it does not find.
 */
export declare function workspaceState(deps: WorkFlowDeps, p: WorkProject): WorkspaceState;
/** One page of STARTABLE projects, NEWEST board first: assigned projects (I'm an anchor owner) + seedable
 *  boards (writable, un-anchored → "not started"). Paginates over BOARDS and resolves the expensive per-board
 *  `canWriteBoard` ONLY for the page (like manageList) — a large org never means a long wait. `totalBoards`
 *  is the full non-closed count (for the "more" affordance). */
export declare function startablePage(deps: WorkFlowDeps, limit: number, offset: number): {
    items: WorkProject[];
    totalBoards: number;
};
export { ensureRootProtocol };
export declare function runWorkFlow(deps: WorkFlowDeps, opts?: WorkFlowOpts): Promise<number>;
