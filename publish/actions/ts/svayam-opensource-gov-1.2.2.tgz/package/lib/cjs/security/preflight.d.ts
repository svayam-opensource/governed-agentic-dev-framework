/**
 * The PREFLIGHT — every command computes its NEED/GAP before it runs, and a non-empty GAP blocks with
 * the command that fixes it. On a healthy machine the GAP is empty and this is a silent no-op.
 *
 * It no longer points at `gov creds`: gov-work has no credential store, and its two NEEDs are satisfied
 * by the user's own tools. So each NEED carries its own instructions and the block prints those.
 */
import { type Need, type NeedProbes } from "./needs.js";
export interface PreflightResult {
    readonly ok: boolean;
    readonly gap: readonly Need[];
}
/** Compute the GAP for a command's NEEDs against this machine's probes. */
export declare function preflight(needs: readonly Need[], probes: NeedProbes): PreflightResult;
/** The block message shown when a command's GAP is non-empty. Each NEED says how to satisfy itself —
 *  a generic "run some other command" would be a lie now that no gov command fills these in. */
export declare function renderGap(gap: readonly Need[]): string[];
